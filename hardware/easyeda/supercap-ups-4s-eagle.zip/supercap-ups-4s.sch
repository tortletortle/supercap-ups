<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="7.0.0">
  <drawing>
    <settings />
    <grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch" />
    <layers>
      <layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes" />
      <layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes" />
      <layer number="93" name="Pins" color="2" fill="1" visible="yes" active="yes" />
      <layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes" />
      <layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes" />
      <layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes" />
      <layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes" />
    </layers>
    <schematic>
      <libraries>
        <library name="UPS">
          <packages />
          <symbols>
            <symbol name="SYM0">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 GND</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 +</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 -</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 V+</text>
            </symbol>
            <symbol name="SYM1">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 V-</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 +</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 -</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 V+</text>
            </symbol>
            <symbol name="SYM2">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-68.58000000000001" width="0.254" layer="94" />
              <wire x1="10.16" y1="-68.58000000000001" x2="-10.16" y2="-68.58000000000001" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-68.58000000000001" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 -</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 +</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 V+</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 +</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 -</text>
              <pin name="P7" x="-12.7" y="-30.48" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-30.98" size="1.27" layer="94">7</text>
              <pin name="P8" x="-12.7" y="-35.56" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-36.06" size="1.27" layer="94">8</text>
              <pin name="P9" x="-12.7" y="-40.64" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-41.14" size="1.27" layer="94">9 -</text>
              <pin name="P10" x="-12.7" y="-45.72" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-46.22" size="1.27" layer="94">10 +</text>
              <pin name="P11" x="-12.7" y="-50.8" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-51.3" size="1.27" layer="94">11 V-</text>
              <pin name="P12" x="-12.7" y="-55.88" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-56.38" size="1.27" layer="94">12 +</text>
              <pin name="P13" x="-12.7" y="-60.96" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-61.46" size="1.27" layer="94">13 -</text>
              <pin name="P14" x="-12.7" y="-66.04" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-66.54" size="1.27" layer="94">14</text>
            </symbol>
            <symbol name="SYM3">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 +</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 V-</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 -</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 V+</text>
            </symbol>
            <symbol name="SYM4">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-99.06" width="0.254" layer="94" />
              <wire x1="10.16" y1="-99.06" x2="-10.16" y2="-99.06" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-99.06" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 VC3A</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 VC3B</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 VC2</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 VC1</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 VC0</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 SRP</text>
              <pin name="P7" x="-12.7" y="-30.48" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-30.98" size="1.27" layer="94">7 SRN</text>
              <pin name="P8" x="-12.7" y="-35.56" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-36.06" size="1.27" layer="94">8 TS</text>
              <pin name="P9" x="-12.7" y="-40.64" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-41.14" size="1.27" layer="94">9 DSG</text>
              <pin name="P10" x="-12.7" y="-45.72" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-46.22" size="1.27" layer="94">10 CHG</text>
              <pin name="P11" x="-12.7" y="-50.8" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-51.3" size="1.27" layer="94">11 VSS</text>
              <pin name="P12" x="-12.7" y="-55.88" length="short" visible="off" direction="io" />
              <text x="-9.4" y="-56.38" size="1.27" layer="94">12 SCL</text>
              <pin name="P13" x="-12.7" y="-60.96" length="short" visible="off" direction="io" />
              <text x="-9.4" y="-61.46" size="1.27" layer="94">13 SDA</text>
              <pin name="P14" x="-12.7" y="-66.04" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-66.54" size="1.27" layer="94">14 ALERT</text>
              <pin name="P15" x="-12.7" y="-71.12" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-71.62" size="1.27" layer="94">15 REGOUT</text>
              <pin name="P16" x="-12.7" y="-76.2" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-76.7" size="1.27" layer="94">16 REGSRC</text>
              <pin name="P17" x="-12.7" y="-81.28" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-81.78" size="1.27" layer="94">17 BAT</text>
              <pin name="P18" x="-12.7" y="-86.36" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-86.86" size="1.27" layer="94">18 VC5</text>
              <pin name="P19" x="-12.7" y="-91.44" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-91.94" size="1.27" layer="94">19 VC4A</text>
              <pin name="P20" x="-12.7" y="-96.52" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-97.02" size="1.27" layer="94">20 VC4B</text>
            </symbol>
            <symbol name="SYM5">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-68.58000000000001" width="0.254" layer="94" />
              <wire x1="10.16" y1="-68.58000000000001" x2="-10.16" y2="-68.58000000000001" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-68.58000000000001" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 V+</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 -</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 +</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 -</text>
              <pin name="P7" x="-12.7" y="-30.48" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-30.98" size="1.27" layer="94">7 +</text>
              <pin name="P8" x="-12.7" y="-35.56" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-36.06" size="1.27" layer="94">8 -</text>
              <pin name="P9" x="-12.7" y="-40.64" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-41.14" size="1.27" layer="94">9 +</text>
              <pin name="P10" x="-12.7" y="-45.72" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-46.22" size="1.27" layer="94">10 -</text>
              <pin name="P11" x="-12.7" y="-50.8" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-51.3" size="1.27" layer="94">11 +</text>
              <pin name="P12" x="-12.7" y="-55.88" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-56.38" size="1.27" layer="94">12 V-</text>
              <pin name="P13" x="-12.7" y="-60.96" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-61.46" size="1.27" layer="94">13</text>
              <pin name="P14" x="-12.7" y="-66.04" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-66.54" size="1.27" layer="94">14</text>
            </symbol>
            <symbol name="SYM6">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-38.1" width="0.254" layer="94" />
              <wire x1="10.16" y1="-38.1" x2="-10.16" y2="-38.1" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-38.1" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="nc" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 DNC</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 Vin</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 Temp</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 GND</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 Trim/NR</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 Vout</text>
              <pin name="P7" x="-12.7" y="-30.48" length="short" visible="off" direction="nc" />
              <text x="-9.4" y="-30.98" size="1.27" layer="94">7 NC</text>
              <pin name="P8" x="-12.7" y="-35.56" length="short" visible="off" direction="nc" />
              <text x="-9.4" y="-36.06" size="1.27" layer="94">8 DNC</text>
            </symbol>
            <symbol name="SYM7">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-27.939999999999998" width="0.254" layer="94" />
              <wire x1="10.16" y1="-27.939999999999998" x2="-10.16" y2="-27.939999999999998" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-27.939999999999998" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 OUTA</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 GND</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 INA+</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 INB-</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 VDD</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 OUTB</text>
            </symbol>
            <symbol name="SYM8">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-2.54" width="0.254" layer="94" />
              <wire x1="10.16" y1="-2.54" x2="-10.16" y2="-2.54" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-2.54" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 1</text>
            </symbol>
            <symbol name="SYM9">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-27.939999999999998" width="0.254" layer="94" />
              <wire x1="10.16" y1="-27.939999999999998" x2="-10.16" y2="-27.939999999999998" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-27.939999999999998" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 Pin_1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 Pin_2</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 Pin_3</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 Pin_4</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 Pin_5</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 Pin_6</text>
            </symbol>
            <symbol name="SYM10">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-33.02" width="0.254" layer="94" />
              <wire x1="10.16" y1="-33.02" x2="-10.16" y2="-33.02" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-33.02" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 Pin_1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 Pin_2</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 Pin_3</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 Pin_4</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 Pin_5</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 Pin_6</text>
              <pin name="P7" x="-12.7" y="-30.48" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-30.98" size="1.27" layer="94">7 Pin_7</text>
            </symbol>
            <symbol name="SYM11">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="10.16" y1="-7.62" x2="-10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-7.62" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2</text>
            </symbol>
            <symbol name="SYM12">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="10.16" y1="-7.62" x2="-10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-7.62" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2</text>
            </symbol>
            <symbol name="SYM13">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="10.16" y1="-7.62" x2="-10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-7.62" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 K</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 A</text>
            </symbol>
            <symbol name="SYM14">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="10.16" y1="-7.62" x2="-10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-7.62" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 2</text>
            </symbol>
            <symbol name="SYM15">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="10.16" y1="-7.62" x2="-10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-7.62" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2</text>
            </symbol>
            <symbol name="SYM16">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="10.16" y1="-7.62" x2="-10.16" y2="-7.62" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-7.62" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 K</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 A</text>
            </symbol>
            <symbol name="SYM17">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-12.7" width="0.254" layer="94" />
              <wire x1="10.16" y1="-12.7" x2="-10.16" y2="-12.7" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-12.7" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 CELL_CONFIG_VALID</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 MANUAL_ARM_REQ</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 GND</text>
            </symbol>
            <symbol name="SYM18">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 A</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 B</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 GND</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 Y</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 VCC</text>
            </symbol>
            <symbol name="SYM19">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 NC</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 A</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 GND</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 Y</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 VCC</text>
            </symbol>
            <symbol name="SYM20">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-38.1" width="0.254" layer="94" />
              <wire x1="10.16" y1="-38.1" x2="-10.16" y2="-38.1" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-38.1" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 CLK</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 D</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 Q_N</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 GND</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 Q</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 CLR_N</text>
              <pin name="P7" x="-12.7" y="-30.48" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-30.98" size="1.27" layer="94">7 PRE_N</text>
              <pin name="P8" x="-12.7" y="-35.56" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-36.06" size="1.27" layer="94">8 VCC</text>
            </symbol>
            <symbol name="SYM21">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-17.78" width="0.254" layer="94" />
              <wire x1="10.16" y1="-17.78" x2="-10.16" y2="-17.78" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-17.78" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 RESET</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 NC</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 GND</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 VDD</text>
            </symbol>
            <symbol name="SYM22">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 OUT</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 V-</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 +</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 -</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 V+</text>
            </symbol>
            <symbol name="SYM23">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-38.1" width="0.254" layer="94" />
              <wire x1="10.16" y1="-38.1" x2="-10.16" y2="-38.1" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-38.1" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="nc" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 DNC</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 Vin</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 Temp</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 GND</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 Trim/NR</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 Vout</text>
              <pin name="P7" x="-12.7" y="-30.48" length="short" visible="off" direction="nc" />
              <text x="-9.4" y="-30.98" size="1.27" layer="94">7 NC</text>
              <pin name="P8" x="-12.7" y="-35.56" length="short" visible="off" direction="nc" />
              <text x="-9.4" y="-36.06" size="1.27" layer="94">8 DNC</text>
            </symbol>
            <symbol name="SYM24">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-27.939999999999998" width="0.254" layer="94" />
              <wire x1="10.16" y1="-27.939999999999998" x2="-10.16" y2="-27.939999999999998" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-27.939999999999998" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 GND</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 SW</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 VIN</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 FB</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 EN</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 BOOT</text>
            </symbol>
            <symbol name="SYM25">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-104.14" width="0.254" layer="94" />
              <wire x1="10.16" y1="-104.14" x2="-10.16" y2="-104.14" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-104.14" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 VCC</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 EN</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 FSW</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 SW</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 SW</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 SW</text>
              <pin name="P7" x="-12.7" y="-30.48" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-30.98" size="1.27" layer="94">7 SW</text>
              <pin name="P8" x="-12.7" y="-35.56" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-36.06" size="1.27" layer="94">8 BOOT</text>
              <pin name="P9" x="-12.7" y="-40.64" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-41.14" size="1.27" layer="94">9 VIN</text>
              <pin name="P10" x="-12.7" y="-45.72" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-46.22" size="1.27" layer="94">10 SS</text>
              <pin name="P11" x="-12.7" y="-50.8" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-51.3" size="1.27" layer="94">11 NC</text>
              <pin name="P12" x="-12.7" y="-55.88" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-56.38" size="1.27" layer="94">12 NC</text>
              <pin name="P13" x="-12.7" y="-60.96" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-61.46" size="1.27" layer="94">13 MODE</text>
              <pin name="P14" x="-12.7" y="-66.04" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-66.54" size="1.27" layer="94">14 VOUT</text>
              <pin name="P15" x="-12.7" y="-71.12" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-71.62" size="1.27" layer="94">15 VOUT</text>
              <pin name="P16" x="-12.7" y="-76.2" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-76.7" size="1.27" layer="94">16 VOUT</text>
              <pin name="P17" x="-12.7" y="-81.28" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-81.78" size="1.27" layer="94">17 FB</text>
              <pin name="P18" x="-12.7" y="-86.36" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-86.86" size="1.27" layer="94">18 COMP</text>
              <pin name="P19" x="-12.7" y="-91.44" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-91.94" size="1.27" layer="94">19 ILIM</text>
              <pin name="P20" x="-12.7" y="-96.52" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-97.02" size="1.27" layer="94">20 AGND</text>
              <pin name="P21" x="-12.7" y="-101.6" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-102.1" size="1.27" layer="94">21 PGND</text>
            </symbol>
            <symbol name="SYM26">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-12.7" width="0.254" layer="94" />
              <wire x1="10.16" y1="-12.7" x2="-10.16" y2="-12.7" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-12.7" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 G</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 S</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 D</text>
            </symbol>
            <symbol name="SYM27">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-12.7" width="0.254" layer="94" />
              <wire x1="10.16" y1="-12.7" x2="-10.16" y2="-12.7" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-12.7" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 G</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 S</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 D</text>
            </symbol>
            <symbol name="SYM28">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-12.7" width="0.254" layer="94" />
              <wire x1="10.16" y1="-12.7" x2="-10.16" y2="-12.7" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-12.7" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 G</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 S</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 D</text>
            </symbol>
            <symbol name="SYM29">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-27.939999999999998" width="0.254" layer="94" />
              <wire x1="10.16" y1="-27.939999999999998" x2="-10.16" y2="-27.939999999999998" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-27.939999999999998" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 OUTA</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 GND</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 INA+</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 INB-</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 VDD</text>
              <pin name="P6" x="-12.7" y="-25.4" length="short" visible="off" direction="oc" />
              <text x="-9.4" y="-25.9" size="1.27" layer="94">6 OUTB</text>
            </symbol>
            <symbol name="SYM30">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="nc" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 NC</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 A</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 GND</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="out" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 Y</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 VCC</text>
            </symbol>
            <symbol name="SYM31">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 IN</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pwr" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 GND</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 EN</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="nc" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 NC</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 OUT</text>
            </symbol>
            <symbol name="SYM32">
              <wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" />
              <wire x1="10.16" y1="5.08" x2="10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="10.16" y1="-22.86" x2="-10.16" y2="-22.86" width="0.254" layer="94" />
              <wire x1="-10.16" y1="-22.86" x2="-10.16" y2="5.08" width="0.254" layer="94" />
              <text x="-10.16" y="10.16" size="1.778" layer="95">&gt;NAME</text>
              <text x="-10.16" y="7.62" size="1.27" layer="96">&gt;VALUE</text>
              <pin name="P1" x="-12.7" y="-0.0" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-0.5" size="1.27" layer="94">1 S</text>
              <pin name="P2" x="-12.7" y="-5.08" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-5.58" size="1.27" layer="94">2 S</text>
              <pin name="P3" x="-12.7" y="-10.16" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-10.66" size="1.27" layer="94">3 S</text>
              <pin name="P4" x="-12.7" y="-15.24" length="short" visible="off" direction="in" />
              <text x="-9.4" y="-15.74" size="1.27" layer="94">4 G</text>
              <pin name="P5" x="-12.7" y="-20.32" length="short" visible="off" direction="pas" />
              <text x="-9.4" y="-20.82" size="1.27" layer="94">5 D</text>
            </symbol>
          </symbols>
          <devicesets>
            <deviceset name="SYM0" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM0" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM1" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM1" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM2" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM2" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM3" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM3" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM4" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM4" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM5" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM5" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM6" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM6" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM7" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM7" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM8" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM8" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM9" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM9" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM10" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM10" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM11" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM11" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM12" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM12" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM13" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM13" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM14" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM14" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM15" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM15" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM16" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM16" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM17" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM17" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM18" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM18" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM19" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM19" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM20" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM20" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM21" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM21" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM22" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM22" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM23" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM23" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM24" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM24" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM25" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM25" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM26" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM26" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM27" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM27" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM28" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM28" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM29" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM29" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM30" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM30" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM31" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM31" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
            <deviceset name="SYM32" uservalue="yes">
              <gates>
                <gate name="G$1" symbol="SYM32" x="0" y="0" />
              </gates>
              <devices>
                <device name="">
                  <technologies>
                    <technology name="" />
                  </technologies>
                </device>
              </devices>
            </deviceset>
          </devicesets>
        </library>
      </libraries>
      <attributes />
      <variantdefs />
      <classes>
        <class number="0" name="default" width="0" drill="0" />
      </classes>
      <parts>
        <part name="C1" library="UPS" deviceset="SYM12" device="" value="20 F / 2.7 V">
          <attribute name="SOURCE_MPN" value="HVH1230-2R7206-R" />
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_THT:CP_Radial_D12.5mm_P5.00mm" />
        </part>
        <part name="C2" library="UPS" deviceset="SYM12" device="" value="20 F / 2.7 V">
          <attribute name="SOURCE_MPN" value="HVH1230-2R7206-R" />
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_THT:CP_Radial_D12.5mm_P5.00mm" />
        </part>
        <part name="C3" library="UPS" deviceset="SYM12" device="" value="20 F / 2.7 V">
          <attribute name="SOURCE_MPN" value="HVH1230-2R7206-R" />
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_THT:CP_Radial_D12.5mm_P5.00mm" />
        </part>
        <part name="C4" library="UPS" deviceset="SYM12" device="" value="20 F / 2.7 V">
          <attribute name="SOURCE_MPN" value="HVH1230-2R7206-R" />
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_THT:CP_Radial_D12.5mm_P5.00mm" />
        </part>
        <part name="C5" library="UPS" deviceset="SYM11" device="" value="35 uF eff." />
        <part name="C6" library="UPS" deviceset="SYM11" device="" value="100 nF" />
        <part name="C7" library="UPS" deviceset="SYM11" device="" value="47 uF eff." />
        <part name="C8" library="UPS" deviceset="SYM11" device="" value="100 nF" />
        <part name="C9" library="UPS" deviceset="SYM11" device="" value="4.7 uF" />
        <part name="C10" library="UPS" deviceset="SYM11" device="" value="47 nF" />
        <part name="C11" library="UPS" deviceset="SYM11" device="" value="13 nF" />
        <part name="C12" library="UPS" deviceset="SYM11" device="" value="100 pF" />
        <part name="L1" library="UPS" deviceset="SYM14" device="" value="3.3 uH" />
        <part name="R1" library="UPS" deviceset="SYM15" device="" value="324 k" />
        <part name="R2" library="UPS" deviceset="SYM15" device="" value="174 k" />
        <part name="R3" library="UPS" deviceset="SYM15" device="" value="21.5 k" />
        <part name="R4" library="UPS" deviceset="SYM15" device="" value="1.076 M" />
        <part name="R5" library="UPS" deviceset="SYM15" device="" value="120 k" />
        <part name="R301" library="UPS" deviceset="SYM15" device="" value="2.2 k / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R302" library="UPS" deviceset="SYM15" device="" value="2.2 k / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R303" library="UPS" deviceset="SYM15" device="" value="2.2 k / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R304" library="UPS" deviceset="SYM15" device="" value="2.2 k / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="TP1" library="UPS" deviceset="SYM8" device="" value="Pack positive" />
        <part name="TP2" library="UPS" deviceset="SYM8" device="" value="External EN" />
        <part name="U1" library="UPS" deviceset="SYM25" device="" value="TPS61088RHL" />
        <part name="C101" library="UPS" deviceset="SYM11" device="" value="22uF / 25V" />
        <part name="C102" library="UPS" deviceset="SYM11" device="" value="100nF / 25V" />
        <part name="C103" library="UPS" deviceset="SYM11" device="" value="100nF / 16V" />
        <part name="C104" library="UPS" deviceset="SYM11" device="" value="22uF / 25V" />
        <part name="C105" library="UPS" deviceset="SYM11" device="" value="22uF / 25V" />
        <part name="C106" library="UPS" deviceset="SYM11" device="" value="100nF" />
        <part name="C107" library="UPS" deviceset="SYM11" device="" value="10nF (tune)" />
        <part name="C108" library="UPS" deviceset="SYM11" device="" value="100nF" />
        <part name="D101" library="UPS" deviceset="SYM13" device="" value="SS34 (candidate)" />
        <part name="D102" library="UPS" deviceset="SYM13" device="" value="BAT54 (candidate)" />
        <part name="J101" library="UPS" deviceset="SYM9" device="" value="CHARGE INTERFACE" />
        <part name="L101" library="UPS" deviceset="SYM14" device="" value="10uH / Isat &gt;= 6A" />
        <part name="R101" library="UPS" deviceset="SYM15" device="" value="30mR / 1%" />
        <part name="R102" library="UPS" deviceset="SYM15" device="" value="4.7k" />
        <part name="R103" library="UPS" deviceset="SYM15" device="" value="47k" />
        <part name="R104" library="UPS" deviceset="SYM15" device="" value="162k / 0.1%" />
        <part name="R105" library="UPS" deviceset="SYM15" device="" value="10k / 0.1%" />
        <part name="R106" library="UPS" deviceset="SYM15" device="" value="100k / 0.1%" />
        <part name="R107" library="UPS" deviceset="SYM15" device="" value="10k / 0.1%" />
        <part name="R108" library="UPS" deviceset="SYM15" device="" value="47k" />
        <part name="R109" library="UPS" deviceset="SYM15" device="" value="10k (tune)" />
        <part name="U101" library="UPS" deviceset="SYM24" device="" value="TPS54302">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-6" />
        </part>
        <part name="U102" library="UPS" deviceset="SYM0" device="" value="INA180A1">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
        </part>
        <part name="U103" library="UPS" deviceset="SYM3" device="" value="TLV9001IDCK">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-353_SC-70-5" />
        </part>
        <part name="C201" library="UPS" deviceset="SYM11" device="" value="100 nF" />
        <part name="C202" library="UPS" deviceset="SYM11" device="" value="1 nF" />
        <part name="R201" library="UPS" deviceset="SYM15" device="" value="174 k" />
        <part name="R202" library="UPS" deviceset="SYM15" device="" value="10.0 k" />
        <part name="R203" library="UPS" deviceset="SYM15" device="" value="1.50 M" />
        <part name="R204" library="UPS" deviceset="SYM15" device="" value="100 k" />
        <part name="R205" library="UPS" deviceset="SYM15" device="" value="68.0 k" />
        <part name="U201" library="UPS" deviceset="SYM29" device="" value="TPS3700DDC">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-6" />
        </part>
        <part name="C401" library="UPS" deviceset="SYM11" device="" value="100 nF">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C402" library="UPS" deviceset="SYM11" device="" value="100 nF">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C403" library="UPS" deviceset="SYM11" device="" value="100 nF">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C404" library="UPS" deviceset="SYM11" device="" value="10 uF X7R">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C405" library="UPS" deviceset="SYM11" device="" value="100 nF">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="R401" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R402" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R403" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R404" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R405" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R406" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R407" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R408" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R409" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R410" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R411" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R412" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R413" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R414" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R415" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R416" library="UPS" deviceset="SYM15" device="" value="1 M / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R417" library="UPS" deviceset="SYM15" device="" value="200 k / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R418" library="UPS" deviceset="SYM15" device="" value="10.0 k / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R419" library="UPS" deviceset="SYM15" device="" value="53.6 k / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="R420" library="UPS" deviceset="SYM15" device="" value="10.0 k / 0.1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0805_2012Metric" />
        </part>
        <part name="U401" library="UPS" deviceset="SYM2" device="" value="OPA4197IPW">
          <attribute name="SOURCE_FOOTPRINT" value="Package_SO:TSSOP-14_4.4x5mm_P0.65mm" />
        </part>
        <part name="U402" library="UPS" deviceset="SYM5" device="" value="LM339BPW">
          <attribute name="SOURCE_FOOTPRINT" value="Package_SO:TSSOP-14_4.4x5mm_P0.65mm" />
        </part>
        <part name="U403" library="UPS" deviceset="SYM6" device="" value="REF5025IDR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_SO:SOIC-8_3.9x4.9mm_P1.27mm" />
        </part>
        <part name="U404" library="UPS" deviceset="SYM7" device="" value="TPS3700DDC">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-6" />
        </part>
        <part name="Q501" library="UPS" deviceset="SYM32" device="" value="Si7149DP">
          <attribute name="SOURCE_FOOTPRINT" value="Package_SO:PowerPAK_SO-8_Single" />
        </part>
        <part name="Q502" library="UPS" deviceset="SYM32" device="" value="Si7149DP">
          <attribute name="SOURCE_FOOTPRINT" value="Package_SO:PowerPAK_SO-8_Single" />
        </part>
        <part name="Q503" library="UPS" deviceset="SYM28" device="" value="AO3400A">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23" />
        </part>
        <part name="Q504" library="UPS" deviceset="SYM28" device="" value="AO3400A">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23" />
        </part>
        <part name="R501" library="UPS" deviceset="SYM15" device="" value="10.0 k" />
        <part name="R502" library="UPS" deviceset="SYM15" device="" value="1.00 k" />
        <part name="R503" library="UPS" deviceset="SYM15" device="" value="1.50 M" />
        <part name="R504" library="UPS" deviceset="SYM15" device="" value="100 k" />
        <part name="C601" library="UPS" deviceset="SYM11" device="" value="1uF" />
        <part name="C602" library="UPS" deviceset="SYM11" device="" value="10uF effective / ESR as specified" />
        <part name="C603" library="UPS" deviceset="SYM11" device="" value="10nF (fit)" />
        <part name="C604" library="UPS" deviceset="SYM11" device="" value="100nF" />
        <part name="C605" library="UPS" deviceset="SYM11" device="" value="1uF" />
        <part name="C606" library="UPS" deviceset="SYM11" device="" value="10uF effective / ESR as specified" />
        <part name="C607" library="UPS" deviceset="SYM11" device="" value="100nF" />
        <part name="D601" library="UPS" deviceset="SYM13" device="" value="BAT54" />
        <part name="J601" library="UPS" deviceset="SYM10" device="" value="BENCH INTERFACE" />
        <part name="Q601" library="UPS" deviceset="SYM27" device="" value="AO3401A">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23" />
        </part>
        <part name="Q602" library="UPS" deviceset="SYM26" device="" value="2N7002">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23" />
        </part>
        <part name="Q603" library="UPS" deviceset="SYM26" device="" value="2N7002">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23" />
        </part>
        <part name="R601" library="UPS" deviceset="SYM15" device="" value="52.60k / ratio matched" />
        <part name="R602" library="UPS" deviceset="SYM15" device="" value="20.00k / ratio matched" />
        <part name="R603" library="UPS" deviceset="SYM15" device="" value="47k" />
        <part name="R604" library="UPS" deviceset="SYM15" device="" value="10k (fit)" />
        <part name="R605" library="UPS" deviceset="SYM15" device="" value="54.20k / ratio matched" />
        <part name="R606" library="UPS" deviceset="SYM15" device="" value="20.00k / ratio matched" />
        <part name="R607" library="UPS" deviceset="SYM15" device="" value="100k" />
        <part name="R608" library="UPS" deviceset="SYM15" device="" value="4.7k" />
        <part name="R609" library="UPS" deviceset="SYM15" device="" value="3.3k" />
        <part name="R610" library="UPS" deviceset="SYM15" device="" value="100k" />
        <part name="U601" library="UPS" deviceset="SYM23" device="" value="REF5025IDR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_SO:SOIC-8_3.9x4.9mm_P1.27mm" />
        </part>
        <part name="U602" library="UPS" deviceset="SYM1" device="" value="OPA333AIDBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
        </part>
        <part name="U603" library="UPS" deviceset="SYM23" device="" value="REF5025IDR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_SO:SOIC-8_3.9x4.9mm_P1.27mm" />
        </part>
        <part name="U604" library="UPS" deviceset="SYM22" device="" value="TLV9031DBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
        </part>
        <part name="C701" library="UPS" deviceset="SYM11" device="" value="1 uF / 50 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C702" library="UPS" deviceset="SYM11" device="" value="4.7 uF / 16 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C703" library="UPS" deviceset="SYM11" device="" value="1 uF / 50 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C704" library="UPS" deviceset="SYM11" device="" value="4.7 uF / 16 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C705" library="UPS" deviceset="SYM11" device="" value="100 nF">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0603_1608Metric" />
        </part>
        <part name="Q703" library="UPS" deviceset="SYM28" device="" value="AO3400A">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23" />
        </part>
        <part name="R705" library="UPS" deviceset="SYM15" device="" value="100 k">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R706" library="UPS" deviceset="SYM15" device="" value="39 k">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="U701" library="UPS" deviceset="SYM31" device="" value="TPS70950DBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
        </part>
        <part name="U702" library="UPS" deviceset="SYM31" device="" value="TPS70950DBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
        </part>
        <part name="U703" library="UPS" deviceset="SYM30" device="" value="SN74LVC1G17DBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
        </part>
        <part name="C801" library="UPS" deviceset="SYM11" device="" value="220 nF / 50 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0603_1608Metric" />
        </part>
        <part name="C802" library="UPS" deviceset="SYM11" device="" value="220 nF / 50 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0603_1608Metric" />
        </part>
        <part name="C803" library="UPS" deviceset="SYM11" device="" value="220 nF / 50 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0603_1608Metric" />
        </part>
        <part name="C804" library="UPS" deviceset="SYM11" device="" value="220 nF / 50 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0603_1608Metric" />
        </part>
        <part name="C805" library="UPS" deviceset="SYM11" device="" value="220 nF / 50 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0603_1608Metric" />
        </part>
        <part name="C806" library="UPS" deviceset="SYM11" device="" value="1 µF / 16 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C807" library="UPS" deviceset="SYM11" device="" value="1 µF / 16 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="C808" library="UPS" deviceset="SYM11" device="" value="1 µF / 6.3 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="D801" library="UPS" deviceset="SYM13" device="" value="Low-leakage diode (TBD)" />
        <part name="D802" library="UPS" deviceset="SYM13" device="" value="Low-leakage diode (TBD)" />
        <part name="R801" library="UPS" deviceset="SYM15" device="" value="10 Ω">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R802" library="UPS" deviceset="SYM15" device="" value="10 Ω">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R803" library="UPS" deviceset="SYM15" device="" value="10 Ω">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R804" library="UPS" deviceset="SYM15" device="" value="10 Ω">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R805" library="UPS" deviceset="SYM15" device="" value="10 Ω">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R806" library="UPS" deviceset="SYM15" device="" value="100 Ω / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R807" library="UPS" deviceset="SYM15" device="" value="10 Ω / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R808" library="UPS" deviceset="SYM15" device="" value="10 kΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R809" library="UPS" deviceset="SYM15" device="" value="10 kΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R810" library="UPS" deviceset="SYM15" device="" value="10 kΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="U801" library="UPS" deviceset="SYM4" device="" value="BQ76905RGRR">
          <attribute name="SOURCE_DATASHEET" value="https://www.ti.com/lit/ds/symlink/bq76905.pdf" />
        </part>
        <part name="C910" library="UPS" deviceset="SYM11" device="" value="1 µF / 16 V">
          <attribute name="SOURCE_FOOTPRINT" value="Capacitor_SMD:C_0805_2012Metric" />
        </part>
        <part name="D910" library="UPS" deviceset="SYM16" device="" value="1N4148W">
          <attribute name="SOURCE_FOOTPRINT" value="Diode_SMD:D_SOD-323" />
          <attribute name="SOURCE_DATASHEET" value="https://www.vishay.com/docs/81857/1n4148w.pdf" />
        </part>
        <part name="J910" library="UPS" deviceset="SYM17" device="" value="Host / arm interface">
          <attribute name="SOURCE_FOOTPRINT" value="Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical" />
        </part>
        <part name="R910" library="UPS" deviceset="SYM15" device="" value="100 kΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R911" library="UPS" deviceset="SYM15" device="" value="1 MΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R912" library="UPS" deviceset="SYM15" device="" value="100 kΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R913" library="UPS" deviceset="SYM15" device="" value="100 kΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R914" library="UPS" deviceset="SYM15" device="" value="100 kΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="R915" library="UPS" deviceset="SYM15" device="" value="100 kΩ / 1%">
          <attribute name="SOURCE_FOOTPRINT" value="Resistor_SMD:R_0603_1608Metric" />
        </part>
        <part name="U910" library="UPS" deviceset="SYM20" device="" value="SN74LVC1G74DCT">
          <attribute name="SOURCE_FOOTPRINT" value="Package_SO:SSOP-8_3x3mm_P0.65mm" />
          <attribute name="SOURCE_DATASHEET" value="https://www.ti.com/lit/ds/symlink/sn74lvc1g74.pdf" />
        </part>
        <part name="U911" library="UPS" deviceset="SYM18" device="" value="SN74LVC1G08DBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
          <attribute name="SOURCE_DATASHEET" value="https://www.ti.com/lit/ds/symlink/sn74lvc1g08.pdf" />
        </part>
        <part name="U912" library="UPS" deviceset="SYM18" device="" value="SN74LVC1G08DBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
          <attribute name="SOURCE_DATASHEET" value="https://www.ti.com/lit/ds/symlink/sn74lvc1g08.pdf" />
        </part>
        <part name="U913" library="UPS" deviceset="SYM18" device="" value="SN74LVC1G08DBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
          <attribute name="SOURCE_DATASHEET" value="https://www.ti.com/lit/ds/symlink/sn74lvc1g08.pdf" />
        </part>
        <part name="U914" library="UPS" deviceset="SYM21" device="" value="TPS3839G33DQNT">
          <attribute name="SOURCE_DATASHEET" value="https://www.ti.com/lit/ds/symlink/tps3839.pdf" />
        </part>
        <part name="U915" library="UPS" deviceset="SYM19" device="" value="SN74LVC1G17DBVR">
          <attribute name="SOURCE_FOOTPRINT" value="Package_TO_SOT_SMD:SOT-23-5" />
          <attribute name="SOURCE_DATASHEET" value="https://www.ti.com/lit/ds/symlink/sn74lvc1g17.pdf" />
        </part>
      </parts>
      <sheets>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | 4S storage and TPS61088 boost</text>
          </plain>
          <instances>
            <instance part="C1" gate="G$1" x="43.18" y="-20.32" />
            <instance part="C2" gate="G$1" x="119.38" y="-20.32" />
            <instance part="C3" gate="G$1" x="195.58" y="-20.32" />
            <instance part="C4" gate="G$1" x="271.78" y="-20.32" />
            <instance part="C5" gate="G$1" x="43.18" y="-50.8" />
            <instance part="C6" gate="G$1" x="119.38" y="-50.8" />
            <instance part="C7" gate="G$1" x="195.58" y="-50.8" />
            <instance part="C8" gate="G$1" x="271.78" y="-50.8" />
            <instance part="C9" gate="G$1" x="43.18" y="-81.28" />
            <instance part="C10" gate="G$1" x="119.38" y="-81.28" />
            <instance part="C11" gate="G$1" x="195.58" y="-81.28" />
            <instance part="C12" gate="G$1" x="271.78" y="-81.28" />
            <instance part="L1" gate="G$1" x="43.18" y="-111.76" />
            <instance part="R1" gate="G$1" x="119.38" y="-111.76" />
            <instance part="R2" gate="G$1" x="195.58" y="-111.76" />
            <instance part="R3" gate="G$1" x="271.78" y="-111.76" />
            <instance part="R4" gate="G$1" x="43.18" y="-142.24" />
            <instance part="R5" gate="G$1" x="119.38" y="-142.24" />
            <instance part="R301" gate="G$1" x="195.58" y="-142.24" />
            <instance part="R302" gate="G$1" x="271.78" y="-142.24" />
            <instance part="R303" gate="G$1" x="43.18" y="-172.72" />
            <instance part="R304" gate="G$1" x="119.38" y="-172.72" />
            <instance part="TP1" gate="G$1" x="195.58" y="-172.72" />
            <instance part="TP2" gate="G$1" x="271.78" y="-172.72" />
            <instance part="U1" gate="G$1" x="43.18" y="-203.2" />
          </instances>
          <busses />
          <nets>
            <net name="PACK_4S" class="0">
              <segment>
                <pinref part="C1" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R301" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-142.24" x2="182.88" y2="-142.24" width="0.1524" layer="91" />
                <label x="154.94" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="TP1" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-172.72" x2="182.88" y2="-172.72" width="0.1524" layer="91" />
                <label x="154.94" y="-172.72" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_3" class="0">
              <segment>
                <pinref part="C1" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C2" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R301" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-147.32" x2="182.88" y2="-147.32" width="0.1524" layer="91" />
                <label x="154.94" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R302" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-142.24" x2="259.08" y2="-142.24" width="0.1524" layer="91" />
                <label x="231.14" y="-142.24" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_2" class="0">
              <segment>
                <pinref part="C2" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C3" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R302" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-147.32" x2="259.08" y2="-147.32" width="0.1524" layer="91" />
                <label x="231.14" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R303" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-172.72" x2="30.48" y2="-172.72" width="0.1524" layer="91" />
                <label x="2.54" y="-172.72" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_1" class="0">
              <segment>
                <pinref part="C3" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C4" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R303" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-177.8" x2="30.48" y2="-177.8" width="0.1524" layer="91" />
                <label x="2.54" y="-177.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R304" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-172.72" x2="106.68" y2="-172.72" width="0.1524" layer="91" />
                <label x="78.74" y="-172.72" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="C4" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C5" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-55.88" x2="30.48" y2="-55.88" width="0.1524" layer="91" />
                <label x="2.54" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C6" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-55.88" x2="106.68" y2="-55.88" width="0.1524" layer="91" />
                <label x="78.74" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C7" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-55.88" x2="182.88" y2="-55.88" width="0.1524" layer="91" />
                <label x="154.94" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C9" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-86.36" x2="30.48" y2="-86.36" width="0.1524" layer="91" />
                <label x="2.54" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C10" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-86.36" x2="106.68" y2="-86.36" width="0.1524" layer="91" />
                <label x="78.74" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C11" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-86.36" x2="182.88" y2="-86.36" width="0.1524" layer="91" />
                <label x="154.94" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C12" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-86.36" x2="259.08" y2="-86.36" width="0.1524" layer="91" />
                <label x="231.14" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R2" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-116.84" x2="182.88" y2="-116.84" width="0.1524" layer="91" />
                <label x="154.94" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R5" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-147.32" x2="106.68" y2="-147.32" width="0.1524" layer="91" />
                <label x="78.74" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R304" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-177.8" x2="106.68" y2="-177.8" width="0.1524" layer="91" />
                <label x="78.74" y="-177.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P11" />
                <wire x1="2.54" y1="-254.0" x2="30.48" y2="-254.0" width="0.1524" layer="91" />
                <label x="2.54" y="-254.0" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P12" />
                <wire x1="2.54" y1="-259.08" x2="30.48" y2="-259.08" width="0.1524" layer="91" />
                <label x="2.54" y="-259.08" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P13" />
                <wire x1="2.54" y1="-264.16" x2="30.48" y2="-264.16" width="0.1524" layer="91" />
                <label x="2.54" y="-264.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P20" />
                <wire x1="2.54" y1="-299.72" x2="30.48" y2="-299.72" width="0.1524" layer="91" />
                <label x="2.54" y="-299.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P21" />
                <wire x1="2.54" y1="-304.8" x2="30.48" y2="-304.8" width="0.1524" layer="91" />
                <label x="2.54" y="-304.8" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="VIN_BOOST" class="0">
              <segment>
                <pinref part="C5" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-50.8" x2="30.48" y2="-50.8" width="0.1524" layer="91" />
                <label x="2.54" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C6" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-50.8" x2="106.68" y2="-50.8" width="0.1524" layer="91" />
                <label x="78.74" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="L1" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-111.76" x2="30.48" y2="-111.76" width="0.1524" layer="91" />
                <label x="2.54" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P9" />
                <wire x1="2.54" y1="-243.84" x2="30.48" y2="-243.84" width="0.1524" layer="91" />
                <label x="2.54" y="-243.84" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="BOOST_12V" class="0">
              <segment>
                <pinref part="C7" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-50.8" x2="182.88" y2="-50.8" width="0.1524" layer="91" />
                <label x="154.94" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R4" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-142.24" x2="30.48" y2="-142.24" width="0.1524" layer="91" />
                <label x="2.54" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P14" />
                <wire x1="2.54" y1="-269.24" x2="30.48" y2="-269.24" width="0.1524" layer="91" />
                <label x="2.54" y="-269.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P15" />
                <wire x1="2.54" y1="-274.32" x2="30.48" y2="-274.32" width="0.1524" layer="91" />
                <label x="2.54" y="-274.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P16" />
                <wire x1="2.54" y1="-279.4" x2="30.48" y2="-279.4" width="0.1524" layer="91" />
                <label x="2.54" y="-279.4" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="BOOT" class="0">
              <segment>
                <pinref part="C8" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-50.8" x2="259.08" y2="-50.8" width="0.1524" layer="91" />
                <label x="231.14" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P8" />
                <wire x1="2.54" y1="-238.76" x2="30.48" y2="-238.76" width="0.1524" layer="91" />
                <label x="2.54" y="-238.76" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="SW" class="0">
              <segment>
                <pinref part="C8" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-55.88" x2="259.08" y2="-55.88" width="0.1524" layer="91" />
                <label x="231.14" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="L1" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-116.84" x2="30.48" y2="-116.84" width="0.1524" layer="91" />
                <label x="2.54" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R1" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-116.84" x2="106.68" y2="-116.84" width="0.1524" layer="91" />
                <label x="78.74" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P4" />
                <wire x1="2.54" y1="-218.44" x2="30.48" y2="-218.44" width="0.1524" layer="91" />
                <label x="2.54" y="-218.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P5" />
                <wire x1="2.54" y1="-223.52" x2="30.48" y2="-223.52" width="0.1524" layer="91" />
                <label x="2.54" y="-223.52" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P6" />
                <wire x1="2.54" y1="-228.6" x2="30.48" y2="-228.6" width="0.1524" layer="91" />
                <label x="2.54" y="-228.6" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P7" />
                <wire x1="2.54" y1="-233.68" x2="30.48" y2="-233.68" width="0.1524" layer="91" />
                <label x="2.54" y="-233.68" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="VCC" class="0">
              <segment>
                <pinref part="C9" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-81.28" x2="30.48" y2="-81.28" width="0.1524" layer="91" />
                <label x="2.54" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-203.2" x2="30.48" y2="-203.2" width="0.1524" layer="91" />
                <label x="2.54" y="-203.2" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="SS" class="0">
              <segment>
                <pinref part="C10" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-81.28" x2="106.68" y2="-81.28" width="0.1524" layer="91" />
                <label x="78.74" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P10" />
                <wire x1="2.54" y1="-248.92" x2="30.48" y2="-248.92" width="0.1524" layer="91" />
                <label x="2.54" y="-248.92" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="COMP_RC" class="0">
              <segment>
                <pinref part="C11" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-81.28" x2="182.88" y2="-81.28" width="0.1524" layer="91" />
                <label x="154.94" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R3" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-116.84" x2="259.08" y2="-116.84" width="0.1524" layer="91" />
                <label x="231.14" y="-116.84" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="COMP" class="0">
              <segment>
                <pinref part="C12" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-81.28" x2="259.08" y2="-81.28" width="0.1524" layer="91" />
                <label x="231.14" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R3" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-111.76" x2="259.08" y2="-111.76" width="0.1524" layer="91" />
                <label x="231.14" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P18" />
                <wire x1="2.54" y1="-289.56" x2="30.48" y2="-289.56" width="0.1524" layer="91" />
                <label x="2.54" y="-289.56" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="FSW" class="0">
              <segment>
                <pinref part="R1" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-111.76" x2="106.68" y2="-111.76" width="0.1524" layer="91" />
                <label x="78.74" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P3" />
                <wire x1="2.54" y1="-213.36" x2="30.48" y2="-213.36" width="0.1524" layer="91" />
                <label x="2.54" y="-213.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="ILIM" class="0">
              <segment>
                <pinref part="R2" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-111.76" x2="182.88" y2="-111.76" width="0.1524" layer="91" />
                <label x="154.94" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P19" />
                <wire x1="2.54" y1="-294.64" x2="30.48" y2="-294.64" width="0.1524" layer="91" />
                <label x="2.54" y="-294.64" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="FB" class="0">
              <segment>
                <pinref part="R4" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-147.32" x2="30.48" y2="-147.32" width="0.1524" layer="91" />
                <label x="2.54" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R5" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-142.24" x2="106.68" y2="-142.24" width="0.1524" layer="91" />
                <label x="78.74" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P17" />
                <wire x1="2.54" y1="-284.48" x2="30.48" y2="-284.48" width="0.1524" layer="91" />
                <label x="2.54" y="-284.48" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="BOOST_EN" class="0">
              <segment>
                <pinref part="TP2" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-172.72" x2="259.08" y2="-172.72" width="0.1524" layer="91" />
                <label x="231.14" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U1" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-208.28" x2="30.48" y2="-208.28" width="0.1524" layer="91" />
                <label x="2.54" y="-208.28" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | TPS54302 CC/CV charger</text>
          </plain>
          <instances>
            <instance part="C101" gate="G$1" x="43.18" y="-20.32" />
            <instance part="C102" gate="G$1" x="119.38" y="-20.32" />
            <instance part="C103" gate="G$1" x="195.58" y="-20.32" />
            <instance part="C104" gate="G$1" x="271.78" y="-20.32" />
            <instance part="C105" gate="G$1" x="43.18" y="-50.8" />
            <instance part="C106" gate="G$1" x="119.38" y="-50.8" />
            <instance part="C107" gate="G$1" x="195.58" y="-50.8" />
            <instance part="C108" gate="G$1" x="271.78" y="-50.8" />
            <instance part="D101" gate="G$1" x="43.18" y="-81.28" />
            <instance part="D102" gate="G$1" x="119.38" y="-81.28" />
            <instance part="J101" gate="G$1" x="195.58" y="-81.28" />
            <instance part="L101" gate="G$1" x="271.78" y="-81.28" />
            <instance part="R101" gate="G$1" x="43.18" y="-132.08" />
            <instance part="R102" gate="G$1" x="119.38" y="-132.08" />
            <instance part="R103" gate="G$1" x="195.58" y="-132.08" />
            <instance part="R104" gate="G$1" x="271.78" y="-132.08" />
            <instance part="R105" gate="G$1" x="43.18" y="-162.56" />
            <instance part="R106" gate="G$1" x="119.38" y="-162.56" />
            <instance part="R107" gate="G$1" x="195.58" y="-162.56" />
            <instance part="R108" gate="G$1" x="271.78" y="-162.56" />
            <instance part="R109" gate="G$1" x="43.18" y="-193.04" />
            <instance part="U101" gate="G$1" x="119.38" y="-193.04" />
            <instance part="U102" gate="G$1" x="195.58" y="-193.04" />
            <instance part="U103" gate="G$1" x="271.78" y="-193.04" />
          </instances>
          <busses />
          <nets>
            <net name="VIN_MAIN" class="0">
              <segment>
                <pinref part="C101" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C102" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="J101" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-81.28" x2="182.88" y2="-81.28" width="0.1524" layer="91" />
                <label x="154.94" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U101" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-203.2" x2="106.68" y2="-203.2" width="0.1524" layer="91" />
                <label x="78.74" y="-203.2" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="C101" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C102" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C104" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C105" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-55.88" x2="30.48" y2="-55.88" width="0.1524" layer="91" />
                <label x="2.54" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C106" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-55.88" x2="106.68" y2="-55.88" width="0.1524" layer="91" />
                <label x="78.74" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C108" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-55.88" x2="259.08" y2="-55.88" width="0.1524" layer="91" />
                <label x="231.14" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="J101" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-86.36" x2="182.88" y2="-86.36" width="0.1524" layer="91" />
                <label x="154.94" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R103" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-137.16" x2="182.88" y2="-137.16" width="0.1524" layer="91" />
                <label x="154.94" y="-137.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R105" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-167.64" x2="30.48" y2="-167.64" width="0.1524" layer="91" />
                <label x="2.54" y="-167.64" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R107" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-167.64" x2="182.88" y2="-167.64" width="0.1524" layer="91" />
                <label x="154.94" y="-167.64" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U101" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-193.04" x2="106.68" y2="-193.04" width="0.1524" layer="91" />
                <label x="78.74" y="-193.04" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U102" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-198.12" x2="182.88" y2="-198.12" width="0.1524" layer="91" />
                <label x="154.94" y="-198.12" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U103" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-198.12" x2="259.08" y2="-198.12" width="0.1524" layer="91" />
                <label x="231.14" y="-198.12" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_BOOT" class="0">
              <segment>
                <pinref part="C103" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U101" gate="G$1" pin="P6" />
                <wire x1="78.74" y1="-218.44" x2="106.68" y2="-218.44" width="0.1524" layer="91" />
                <label x="78.74" y="-218.44" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_SW" class="0">
              <segment>
                <pinref part="C103" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="L101" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-81.28" x2="259.08" y2="-81.28" width="0.1524" layer="91" />
                <label x="231.14" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U101" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-198.12" x2="106.68" y2="-198.12" width="0.1524" layer="91" />
                <label x="78.74" y="-198.12" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_BUCK" class="0">
              <segment>
                <pinref part="C104" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C105" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-50.8" x2="30.48" y2="-50.8" width="0.1524" layer="91" />
                <label x="2.54" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="L101" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-86.36" x2="259.08" y2="-86.36" width="0.1524" layer="91" />
                <label x="231.14" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R101" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-132.08" x2="30.48" y2="-132.08" width="0.1524" layer="91" />
                <label x="2.54" y="-132.08" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R104" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-132.08" x2="259.08" y2="-132.08" width="0.1524" layer="91" />
                <label x="231.14" y="-132.08" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U102" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-203.2" x2="182.88" y2="-203.2" width="0.1524" layer="91" />
                <label x="154.94" y="-203.2" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="3V3_CHG" class="0">
              <segment>
                <pinref part="C106" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-50.8" x2="106.68" y2="-50.8" width="0.1524" layer="91" />
                <label x="78.74" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C108" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-50.8" x2="259.08" y2="-50.8" width="0.1524" layer="91" />
                <label x="231.14" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="J101" gate="G$1" pin="P6" />
                <wire x1="154.94" y1="-106.68" x2="182.88" y2="-106.68" width="0.1524" layer="91" />
                <label x="154.94" y="-106.68" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R106" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-162.56" x2="106.68" y2="-162.56" width="0.1524" layer="91" />
                <label x="78.74" y="-162.56" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U102" gate="G$1" pin="P5" />
                <wire x1="154.94" y1="-213.36" x2="182.88" y2="-213.36" width="0.1524" layer="91" />
                <label x="154.94" y="-213.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U103" gate="G$1" pin="P5" />
                <wire x1="231.14" y1="-213.36" x2="259.08" y2="-213.36" width="0.1524" layer="91" />
                <label x="231.14" y="-213.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_CC_OUT" class="0">
              <segment>
                <pinref part="C107" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-50.8" x2="182.88" y2="-50.8" width="0.1524" layer="91" />
                <label x="154.94" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="D102" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-86.36" x2="106.68" y2="-86.36" width="0.1524" layer="91" />
                <label x="78.74" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U103" gate="G$1" pin="P4" />
                <wire x1="231.14" y1="-208.28" x2="259.08" y2="-208.28" width="0.1524" layer="91" />
                <label x="231.14" y="-208.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_CC_NEG" class="0">
              <segment>
                <pinref part="C107" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-55.88" x2="182.88" y2="-55.88" width="0.1524" layer="91" />
                <label x="154.94" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R108" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-167.64" x2="259.08" y2="-167.64" width="0.1524" layer="91" />
                <label x="231.14" y="-167.64" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U103" gate="G$1" pin="P3" />
                <wire x1="231.14" y1="-203.2" x2="259.08" y2="-203.2" width="0.1524" layer="91" />
                <label x="231.14" y="-203.2" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_DIODE_K" class="0">
              <segment>
                <pinref part="D101" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-81.28" x2="30.48" y2="-81.28" width="0.1524" layer="91" />
                <label x="2.54" y="-81.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_DIODE_IN" class="0">
              <segment>
                <pinref part="D101" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-86.36" x2="30.48" y2="-86.36" width="0.1524" layer="91" />
                <label x="2.54" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R101" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-137.16" x2="30.48" y2="-137.16" width="0.1524" layer="91" />
                <label x="2.54" y="-137.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U102" gate="G$1" pin="P4" />
                <wire x1="154.94" y1="-208.28" x2="182.88" y2="-208.28" width="0.1524" layer="91" />
                <label x="154.94" y="-208.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_CC_DIODE" class="0">
              <segment>
                <pinref part="D102" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-81.28" x2="106.68" y2="-81.28" width="0.1524" layer="91" />
                <label x="78.74" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R109" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-193.04" x2="30.48" y2="-193.04" width="0.1524" layer="91" />
                <label x="2.54" y="-193.04" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_4S" class="0">
              <segment>
                <pinref part="J101" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-91.44" x2="182.88" y2="-91.44" width="0.1524" layer="91" />
                <label x="154.94" y="-91.44" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_ALLOW" class="0">
              <segment>
                <pinref part="J101" gate="G$1" pin="P4" />
                <wire x1="154.94" y1="-96.52" x2="182.88" y2="-96.52" width="0.1524" layer="91" />
                <label x="154.94" y="-96.52" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R102" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-132.08" x2="106.68" y2="-132.08" width="0.1524" layer="91" />
                <label x="78.74" y="-132.08" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_OVP_OD" class="0">
              <segment>
                <pinref part="J101" gate="G$1" pin="P5" />
                <wire x1="154.94" y1="-101.6" x2="182.88" y2="-101.6" width="0.1524" layer="91" />
                <label x="154.94" y="-101.6" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R102" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-137.16" x2="106.68" y2="-137.16" width="0.1524" layer="91" />
                <label x="78.74" y="-137.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R103" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-132.08" x2="182.88" y2="-132.08" width="0.1524" layer="91" />
                <label x="154.94" y="-132.08" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U101" gate="G$1" pin="P5" />
                <wire x1="78.74" y1="-213.36" x2="106.68" y2="-213.36" width="0.1524" layer="91" />
                <label x="78.74" y="-213.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_FB" class="0">
              <segment>
                <pinref part="R104" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-137.16" x2="259.08" y2="-137.16" width="0.1524" layer="91" />
                <label x="231.14" y="-137.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R105" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-162.56" x2="30.48" y2="-162.56" width="0.1524" layer="91" />
                <label x="2.54" y="-162.56" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R109" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-198.12" x2="30.48" y2="-198.12" width="0.1524" layer="91" />
                <label x="2.54" y="-198.12" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U101" gate="G$1" pin="P4" />
                <wire x1="78.74" y1="-208.28" x2="106.68" y2="-208.28" width="0.1524" layer="91" />
                <label x="78.74" y="-208.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_ISET" class="0">
              <segment>
                <pinref part="R106" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-167.64" x2="106.68" y2="-167.64" width="0.1524" layer="91" />
                <label x="78.74" y="-167.64" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R107" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-162.56" x2="182.88" y2="-162.56" width="0.1524" layer="91" />
                <label x="154.94" y="-162.56" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R108" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-162.56" x2="259.08" y2="-162.56" width="0.1524" layer="91" />
                <label x="231.14" y="-162.56" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_ISENSE" class="0">
              <segment>
                <pinref part="U102" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-193.04" x2="182.88" y2="-193.04" width="0.1524" layer="91" />
                <label x="154.94" y="-193.04" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U103" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-193.04" x2="259.08" y2="-193.04" width="0.1524" layer="91" />
                <label x="231.14" y="-193.04" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | Pack undervoltage lockout</text>
          </plain>
          <instances>
            <instance part="C201" gate="G$1" x="43.18" y="-20.32" />
            <instance part="C202" gate="G$1" x="119.38" y="-20.32" />
            <instance part="R201" gate="G$1" x="195.58" y="-20.32" />
            <instance part="R202" gate="G$1" x="271.78" y="-20.32" />
            <instance part="R203" gate="G$1" x="43.18" y="-50.8" />
            <instance part="R204" gate="G$1" x="119.38" y="-50.8" />
            <instance part="R205" gate="G$1" x="195.58" y="-50.8" />
            <instance part="U201" gate="G$1" x="271.78" y="-50.8" />
          </instances>
          <busses />
          <nets>
            <net name="PACK_4S" class="0">
              <segment>
                <pinref part="C201" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R201" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R204" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-50.8" x2="106.68" y2="-50.8" width="0.1524" layer="91" />
                <label x="78.74" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U201" gate="G$1" pin="P5" />
                <wire x1="231.14" y1="-71.12" x2="259.08" y2="-71.12" width="0.1524" layer="91" />
                <label x="231.14" y="-71.12" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="C201" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C202" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R202" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R205" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-55.88" x2="182.88" y2="-55.88" width="0.1524" layer="91" />
                <label x="154.94" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U201" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-55.88" x2="259.08" y2="-55.88" width="0.1524" layer="91" />
                <label x="231.14" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U201" gate="G$1" pin="P4" />
                <wire x1="231.14" y1="-66.04" x2="259.08" y2="-66.04" width="0.1524" layer="91" />
                <label x="231.14" y="-66.04" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="UV_SENSE" class="0">
              <segment>
                <pinref part="C202" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R201" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R202" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R203" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-50.8" x2="30.48" y2="-50.8" width="0.1524" layer="91" />
                <label x="2.54" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U201" gate="G$1" pin="P3" />
                <wire x1="231.14" y1="-60.96" x2="259.08" y2="-60.96" width="0.1524" layer="91" />
                <label x="231.14" y="-60.96" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_UV_OK" class="0">
              <segment>
                <pinref part="R203" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-55.88" x2="30.48" y2="-55.88" width="0.1524" layer="91" />
                <label x="2.54" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R204" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-55.88" x2="106.68" y2="-55.88" width="0.1524" layer="91" />
                <label x="78.74" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R205" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-50.8" x2="182.88" y2="-50.8" width="0.1524" layer="91" />
                <label x="154.94" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U201" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-50.8" x2="259.08" y2="-50.8" width="0.1524" layer="91" />
                <label x="231.14" y="-50.8" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_91" class="0">
              <segment>
                <pinref part="U201" gate="G$1" pin="P6" />
                <wire x1="231.14" y1="-76.2" x2="259.08" y2="-76.2" width="0.1524" layer="91" />
                <label x="231.14" y="-76.2" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | 4S cell overvoltage interlock</text>
          </plain>
          <instances>
            <instance part="C401" gate="G$1" x="43.18" y="-20.32" />
            <instance part="C402" gate="G$1" x="119.38" y="-20.32" />
            <instance part="C403" gate="G$1" x="195.58" y="-20.32" />
            <instance part="C404" gate="G$1" x="271.78" y="-20.32" />
            <instance part="C405" gate="G$1" x="43.18" y="-50.8" />
            <instance part="R401" gate="G$1" x="119.38" y="-50.8" />
            <instance part="R402" gate="G$1" x="195.58" y="-50.8" />
            <instance part="R403" gate="G$1" x="271.78" y="-50.8" />
            <instance part="R404" gate="G$1" x="43.18" y="-81.28" />
            <instance part="R405" gate="G$1" x="119.38" y="-81.28" />
            <instance part="R406" gate="G$1" x="195.58" y="-81.28" />
            <instance part="R407" gate="G$1" x="271.78" y="-81.28" />
            <instance part="R408" gate="G$1" x="43.18" y="-111.76" />
            <instance part="R409" gate="G$1" x="119.38" y="-111.76" />
            <instance part="R410" gate="G$1" x="195.58" y="-111.76" />
            <instance part="R411" gate="G$1" x="271.78" y="-111.76" />
            <instance part="R412" gate="G$1" x="43.18" y="-142.24" />
            <instance part="R413" gate="G$1" x="119.38" y="-142.24" />
            <instance part="R414" gate="G$1" x="195.58" y="-142.24" />
            <instance part="R415" gate="G$1" x="271.78" y="-142.24" />
            <instance part="R416" gate="G$1" x="43.18" y="-172.72" />
            <instance part="R417" gate="G$1" x="119.38" y="-172.72" />
            <instance part="R418" gate="G$1" x="195.58" y="-172.72" />
            <instance part="R419" gate="G$1" x="271.78" y="-172.72" />
            <instance part="R420" gate="G$1" x="43.18" y="-203.2" />
            <instance part="U401" gate="G$1" x="119.38" y="-203.2" />
            <instance part="U402" gate="G$1" x="195.58" y="-203.2" />
            <instance part="U403" gate="G$1" x="271.78" y="-203.2" />
            <instance part="U404" gate="G$1" x="43.18" y="-294.64" />
          </instances>
          <busses />
          <nets>
            <net name="VIN_MAIN" class="0">
              <segment>
                <pinref part="C401" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C402" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C403" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C405" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-50.8" x2="30.48" y2="-50.8" width="0.1524" layer="91" />
                <label x="2.54" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R417" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-172.72" x2="106.68" y2="-172.72" width="0.1524" layer="91" />
                <label x="78.74" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P4" />
                <wire x1="78.74" y1="-218.44" x2="106.68" y2="-218.44" width="0.1524" layer="91" />
                <label x="78.74" y="-218.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-213.36" x2="182.88" y2="-213.36" width="0.1524" layer="91" />
                <label x="154.94" y="-213.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U403" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-208.28" x2="259.08" y2="-208.28" width="0.1524" layer="91" />
                <label x="231.14" y="-208.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U404" gate="G$1" pin="P5" />
                <wire x1="2.54" y1="-314.96" x2="30.48" y2="-314.96" width="0.1524" layer="91" />
                <label x="2.54" y="-314.96" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="C401" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C402" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C403" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C404" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C405" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-55.88" x2="30.48" y2="-55.88" width="0.1524" layer="91" />
                <label x="2.54" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R402" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-55.88" x2="182.88" y2="-55.88" width="0.1524" layer="91" />
                <label x="154.94" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R403" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-50.8" x2="259.08" y2="-50.8" width="0.1524" layer="91" />
                <label x="231.14" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R406" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-86.36" x2="182.88" y2="-86.36" width="0.1524" layer="91" />
                <label x="154.94" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R410" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-116.84" x2="182.88" y2="-116.84" width="0.1524" layer="91" />
                <label x="154.94" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R414" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-147.32" x2="182.88" y2="-147.32" width="0.1524" layer="91" />
                <label x="154.94" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R418" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-177.8" x2="182.88" y2="-177.8" width="0.1524" layer="91" />
                <label x="154.94" y="-177.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R420" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-208.28" x2="30.48" y2="-208.28" width="0.1524" layer="91" />
                <label x="2.54" y="-208.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P11" />
                <wire x1="78.74" y1="-254.0" x2="106.68" y2="-254.0" width="0.1524" layer="91" />
                <label x="78.74" y="-254.0" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P12" />
                <wire x1="154.94" y1="-259.08" x2="182.88" y2="-259.08" width="0.1524" layer="91" />
                <label x="154.94" y="-259.08" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U403" gate="G$1" pin="P4" />
                <wire x1="231.14" y1="-218.44" x2="259.08" y2="-218.44" width="0.1524" layer="91" />
                <label x="231.14" y="-218.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U404" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-299.72" x2="30.48" y2="-299.72" width="0.1524" layer="91" />
                <label x="2.54" y="-299.72" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="OV_REF" class="0">
              <segment>
                <pinref part="C404" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R419" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-172.72" x2="259.08" y2="-172.72" width="0.1524" layer="91" />
                <label x="231.14" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P5" />
                <wire x1="154.94" y1="-223.52" x2="182.88" y2="-223.52" width="0.1524" layer="91" />
                <label x="154.94" y="-223.52" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P7" />
                <wire x1="154.94" y1="-233.68" x2="182.88" y2="-233.68" width="0.1524" layer="91" />
                <label x="154.94" y="-233.68" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P9" />
                <wire x1="154.94" y1="-243.84" x2="182.88" y2="-243.84" width="0.1524" layer="91" />
                <label x="154.94" y="-243.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P11" />
                <wire x1="154.94" y1="-254.0" x2="182.88" y2="-254.0" width="0.1524" layer="91" />
                <label x="154.94" y="-254.0" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U403" gate="G$1" pin="P6" />
                <wire x1="231.14" y1="-228.6" x2="259.08" y2="-228.6" width="0.1524" layer="91" />
                <label x="231.14" y="-228.6" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_1" class="0">
              <segment>
                <pinref part="R401" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-50.8" x2="106.68" y2="-50.8" width="0.1524" layer="91" />
                <label x="78.74" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R407" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-81.28" x2="259.08" y2="-81.28" width="0.1524" layer="91" />
                <label x="231.14" y="-81.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_73" class="0">
              <segment>
                <pinref part="R401" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-55.88" x2="106.68" y2="-55.88" width="0.1524" layer="91" />
                <label x="78.74" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R402" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-50.8" x2="182.88" y2="-50.8" width="0.1524" layer="91" />
                <label x="154.94" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-213.36" x2="106.68" y2="-213.36" width="0.1524" layer="91" />
                <label x="78.74" y="-213.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_74" class="0">
              <segment>
                <pinref part="R403" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-55.88" x2="259.08" y2="-55.88" width="0.1524" layer="91" />
                <label x="231.14" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R404" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-81.28" x2="30.48" y2="-81.28" width="0.1524" layer="91" />
                <label x="2.54" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-208.28" x2="106.68" y2="-208.28" width="0.1524" layer="91" />
                <label x="78.74" y="-208.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="VCELL_1" class="0">
              <segment>
                <pinref part="R404" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-86.36" x2="30.48" y2="-86.36" width="0.1524" layer="91" />
                <label x="2.54" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-203.2" x2="106.68" y2="-203.2" width="0.1524" layer="91" />
                <label x="78.74" y="-203.2" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P4" />
                <wire x1="154.94" y1="-218.44" x2="182.88" y2="-218.44" width="0.1524" layer="91" />
                <label x="154.94" y="-218.44" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_2" class="0">
              <segment>
                <pinref part="R405" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-81.28" x2="106.68" y2="-81.28" width="0.1524" layer="91" />
                <label x="78.74" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R411" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-111.76" x2="259.08" y2="-111.76" width="0.1524" layer="91" />
                <label x="231.14" y="-111.76" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_75" class="0">
              <segment>
                <pinref part="R405" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-86.36" x2="106.68" y2="-86.36" width="0.1524" layer="91" />
                <label x="78.74" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R406" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-81.28" x2="182.88" y2="-81.28" width="0.1524" layer="91" />
                <label x="154.94" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P5" />
                <wire x1="78.74" y1="-223.52" x2="106.68" y2="-223.52" width="0.1524" layer="91" />
                <label x="78.74" y="-223.52" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_76" class="0">
              <segment>
                <pinref part="R407" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-86.36" x2="259.08" y2="-86.36" width="0.1524" layer="91" />
                <label x="231.14" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R408" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-111.76" x2="30.48" y2="-111.76" width="0.1524" layer="91" />
                <label x="2.54" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P6" />
                <wire x1="78.74" y1="-228.6" x2="106.68" y2="-228.6" width="0.1524" layer="91" />
                <label x="78.74" y="-228.6" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="VCELL_2" class="0">
              <segment>
                <pinref part="R408" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-116.84" x2="30.48" y2="-116.84" width="0.1524" layer="91" />
                <label x="2.54" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P7" />
                <wire x1="78.74" y1="-233.68" x2="106.68" y2="-233.68" width="0.1524" layer="91" />
                <label x="78.74" y="-233.68" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P6" />
                <wire x1="154.94" y1="-228.6" x2="182.88" y2="-228.6" width="0.1524" layer="91" />
                <label x="154.94" y="-228.6" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_3" class="0">
              <segment>
                <pinref part="R409" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-111.76" x2="106.68" y2="-111.76" width="0.1524" layer="91" />
                <label x="78.74" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R415" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-142.24" x2="259.08" y2="-142.24" width="0.1524" layer="91" />
                <label x="231.14" y="-142.24" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_77" class="0">
              <segment>
                <pinref part="R409" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-116.84" x2="106.68" y2="-116.84" width="0.1524" layer="91" />
                <label x="78.74" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R410" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-111.76" x2="182.88" y2="-111.76" width="0.1524" layer="91" />
                <label x="154.94" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P10" />
                <wire x1="78.74" y1="-248.92" x2="106.68" y2="-248.92" width="0.1524" layer="91" />
                <label x="78.74" y="-248.92" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_78" class="0">
              <segment>
                <pinref part="R411" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-116.84" x2="259.08" y2="-116.84" width="0.1524" layer="91" />
                <label x="231.14" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R412" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-142.24" x2="30.48" y2="-142.24" width="0.1524" layer="91" />
                <label x="2.54" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P9" />
                <wire x1="78.74" y1="-243.84" x2="106.68" y2="-243.84" width="0.1524" layer="91" />
                <label x="78.74" y="-243.84" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="VCELL_3" class="0">
              <segment>
                <pinref part="R412" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-147.32" x2="30.48" y2="-147.32" width="0.1524" layer="91" />
                <label x="2.54" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P8" />
                <wire x1="78.74" y1="-238.76" x2="106.68" y2="-238.76" width="0.1524" layer="91" />
                <label x="78.74" y="-238.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P10" />
                <wire x1="154.94" y1="-248.92" x2="182.88" y2="-248.92" width="0.1524" layer="91" />
                <label x="154.94" y="-248.92" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_4S" class="0">
              <segment>
                <pinref part="R413" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-142.24" x2="106.68" y2="-142.24" width="0.1524" layer="91" />
                <label x="78.74" y="-142.24" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_79" class="0">
              <segment>
                <pinref part="R413" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-147.32" x2="106.68" y2="-147.32" width="0.1524" layer="91" />
                <label x="78.74" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R414" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-142.24" x2="182.88" y2="-142.24" width="0.1524" layer="91" />
                <label x="154.94" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P12" />
                <wire x1="78.74" y1="-259.08" x2="106.68" y2="-259.08" width="0.1524" layer="91" />
                <label x="78.74" y="-259.08" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_80" class="0">
              <segment>
                <pinref part="R415" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-147.32" x2="259.08" y2="-147.32" width="0.1524" layer="91" />
                <label x="231.14" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R416" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-172.72" x2="30.48" y2="-172.72" width="0.1524" layer="91" />
                <label x="2.54" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P13" />
                <wire x1="78.74" y1="-264.16" x2="106.68" y2="-264.16" width="0.1524" layer="91" />
                <label x="78.74" y="-264.16" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="VCELL_4" class="0">
              <segment>
                <pinref part="R416" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-177.8" x2="30.48" y2="-177.8" width="0.1524" layer="91" />
                <label x="2.54" y="-177.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U401" gate="G$1" pin="P14" />
                <wire x1="78.74" y1="-269.24" x2="106.68" y2="-269.24" width="0.1524" layer="91" />
                <label x="78.74" y="-269.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P8" />
                <wire x1="154.94" y1="-238.76" x2="182.88" y2="-238.76" width="0.1524" layer="91" />
                <label x="154.94" y="-238.76" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="SUP_MAIN_SENSE" class="0">
              <segment>
                <pinref part="R417" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-177.8" x2="106.68" y2="-177.8" width="0.1524" layer="91" />
                <label x="78.74" y="-177.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R418" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-172.72" x2="182.88" y2="-172.72" width="0.1524" layer="91" />
                <label x="154.94" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U404" gate="G$1" pin="P3" />
                <wire x1="2.54" y1="-304.8" x2="30.48" y2="-304.8" width="0.1524" layer="91" />
                <label x="2.54" y="-304.8" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="SUP_REF_SENSE" class="0">
              <segment>
                <pinref part="R419" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-177.8" x2="259.08" y2="-177.8" width="0.1524" layer="91" />
                <label x="231.14" y="-177.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R420" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-203.2" x2="30.48" y2="-203.2" width="0.1524" layer="91" />
                <label x="2.54" y="-203.2" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U404" gate="G$1" pin="P4" />
                <wire x1="2.54" y1="-309.88" x2="30.48" y2="-309.88" width="0.1524" layer="91" />
                <label x="2.54" y="-309.88" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_OVP_OD" class="0">
              <segment>
                <pinref part="U402" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-203.2" x2="182.88" y2="-203.2" width="0.1524" layer="91" />
                <label x="154.94" y="-203.2" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-208.28" x2="182.88" y2="-208.28" width="0.1524" layer="91" />
                <label x="154.94" y="-208.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P13" />
                <wire x1="154.94" y1="-264.16" x2="182.88" y2="-264.16" width="0.1524" layer="91" />
                <label x="154.94" y="-264.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U402" gate="G$1" pin="P14" />
                <wire x1="154.94" y1="-269.24" x2="182.88" y2="-269.24" width="0.1524" layer="91" />
                <label x="154.94" y="-269.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U404" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-294.64" x2="30.48" y2="-294.64" width="0.1524" layer="91" />
                <label x="2.54" y="-294.64" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U404" gate="G$1" pin="P6" />
                <wire x1="2.54" y1="-320.04" x2="30.48" y2="-320.04" width="0.1524" layer="91" />
                <label x="2.54" y="-320.04" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_92" class="0">
              <segment>
                <pinref part="U403" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-203.2" x2="259.08" y2="-203.2" width="0.1524" layer="91" />
                <label x="231.14" y="-203.2" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_95" class="0">
              <segment>
                <pinref part="U403" gate="G$1" pin="P3" />
                <wire x1="231.14" y1="-213.36" x2="259.08" y2="-213.36" width="0.1524" layer="91" />
                <label x="231.14" y="-213.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_96" class="0">
              <segment>
                <pinref part="U403" gate="G$1" pin="P5" />
                <wire x1="231.14" y1="-223.52" x2="259.08" y2="-223.52" width="0.1524" layer="91" />
                <label x="231.14" y="-223.52" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_94" class="0">
              <segment>
                <pinref part="U403" gate="G$1" pin="P7" />
                <wire x1="231.14" y1="-233.68" x2="259.08" y2="-233.68" width="0.1524" layer="91" />
                <label x="231.14" y="-233.68" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_93" class="0">
              <segment>
                <pinref part="U403" gate="G$1" pin="P8" />
                <wire x1="231.14" y1="-238.76" x2="259.08" y2="-238.76" width="0.1524" layer="91" />
                <label x="231.14" y="-238.76" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | Pack discharge switch</text>
          </plain>
          <instances>
            <instance part="Q501" gate="G$1" x="43.18" y="-20.32" />
            <instance part="Q502" gate="G$1" x="119.38" y="-20.32" />
            <instance part="Q503" gate="G$1" x="195.58" y="-20.32" />
            <instance part="Q504" gate="G$1" x="271.78" y="-20.32" />
            <instance part="R501" gate="G$1" x="43.18" y="-66.04" />
            <instance part="R502" gate="G$1" x="119.38" y="-66.04" />
            <instance part="R503" gate="G$1" x="195.58" y="-66.04" />
            <instance part="R504" gate="G$1" x="271.78" y="-66.04" />
          </instances>
          <busses />
          <nets>
            <net name="SW_COMMON_SOURCE" class="0">
              <segment>
                <pinref part="Q501" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q501" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q501" gate="G$1" pin="P3" />
                <wire x1="2.54" y1="-30.48" x2="30.48" y2="-30.48" width="0.1524" layer="91" />
                <label x="2.54" y="-30.48" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q502" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q502" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q502" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-30.48" x2="106.68" y2="-30.48" width="0.1524" layer="91" />
                <label x="78.74" y="-30.48" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R501" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-66.04" x2="30.48" y2="-66.04" width="0.1524" layer="91" />
                <label x="2.54" y="-66.04" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="SW_PGATE" class="0">
              <segment>
                <pinref part="Q501" gate="G$1" pin="P4" />
                <wire x1="2.54" y1="-35.56" x2="30.48" y2="-35.56" width="0.1524" layer="91" />
                <label x="2.54" y="-35.56" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q502" gate="G$1" pin="P4" />
                <wire x1="78.74" y1="-35.56" x2="106.68" y2="-35.56" width="0.1524" layer="91" />
                <label x="78.74" y="-35.56" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R501" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-71.12" x2="30.48" y2="-71.12" width="0.1524" layer="91" />
                <label x="2.54" y="-71.12" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R502" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-66.04" x2="106.68" y2="-66.04" width="0.1524" layer="91" />
                <label x="78.74" y="-66.04" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_4S" class="0">
              <segment>
                <pinref part="Q501" gate="G$1" pin="P5" />
                <wire x1="2.54" y1="-40.64" x2="30.48" y2="-40.64" width="0.1524" layer="91" />
                <label x="2.54" y="-40.64" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="VIN_BOOST" class="0">
              <segment>
                <pinref part="Q502" gate="G$1" pin="P5" />
                <wire x1="78.74" y1="-40.64" x2="106.68" y2="-40.64" width="0.1524" layer="91" />
                <label x="78.74" y="-40.64" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_UV_OK" class="0">
              <segment>
                <pinref part="Q503" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R503" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-66.04" x2="182.88" y2="-66.04" width="0.1524" layer="91" />
                <label x="154.94" y="-66.04" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_72" class="0">
              <segment>
                <pinref part="Q503" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q504" gate="G$1" pin="P3" />
                <wire x1="231.14" y1="-30.48" x2="259.08" y2="-30.48" width="0.1524" layer="91" />
                <label x="231.14" y="-30.48" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_71" class="0">
              <segment>
                <pinref part="Q503" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-30.48" x2="182.88" y2="-30.48" width="0.1524" layer="91" />
                <label x="154.94" y="-30.48" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R502" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-71.12" x2="106.68" y2="-71.12" width="0.1524" layer="91" />
                <label x="78.74" y="-71.12" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="DISCHARGE_ARM" class="0">
              <segment>
                <pinref part="Q504" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R504" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-66.04" x2="259.08" y2="-66.04" width="0.1524" layer="91" />
                <label x="231.14" y="-66.04" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="Q504" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R503" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-71.12" x2="182.88" y2="-71.12" width="0.1524" layer="91" />
                <label x="154.94" y="-71.12" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R504" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-71.12" x2="259.08" y2="-71.12" width="0.1524" layer="91" />
                <label x="231.14" y="-71.12" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | Precision CV and independent OVP</text>
          </plain>
          <instances>
            <instance part="C601" gate="G$1" x="43.18" y="-20.32" />
            <instance part="C602" gate="G$1" x="119.38" y="-20.32" />
            <instance part="C603" gate="G$1" x="195.58" y="-20.32" />
            <instance part="C604" gate="G$1" x="271.78" y="-20.32" />
            <instance part="C605" gate="G$1" x="43.18" y="-50.8" />
            <instance part="C606" gate="G$1" x="119.38" y="-50.8" />
            <instance part="C607" gate="G$1" x="195.58" y="-50.8" />
            <instance part="D601" gate="G$1" x="271.78" y="-50.8" />
            <instance part="J601" gate="G$1" x="43.18" y="-81.28" />
            <instance part="Q601" gate="G$1" x="119.38" y="-81.28" />
            <instance part="Q602" gate="G$1" x="195.58" y="-81.28" />
            <instance part="Q603" gate="G$1" x="271.78" y="-81.28" />
            <instance part="R601" gate="G$1" x="43.18" y="-137.16" />
            <instance part="R602" gate="G$1" x="119.38" y="-137.16" />
            <instance part="R603" gate="G$1" x="195.58" y="-137.16" />
            <instance part="R604" gate="G$1" x="271.78" y="-137.16" />
            <instance part="R605" gate="G$1" x="43.18" y="-167.64" />
            <instance part="R606" gate="G$1" x="119.38" y="-167.64" />
            <instance part="R607" gate="G$1" x="195.58" y="-167.64" />
            <instance part="R608" gate="G$1" x="271.78" y="-167.64" />
            <instance part="R609" gate="G$1" x="43.18" y="-198.12" />
            <instance part="R610" gate="G$1" x="119.38" y="-198.12" />
            <instance part="U601" gate="G$1" x="195.58" y="-198.12" />
            <instance part="U602" gate="G$1" x="271.78" y="-198.12" />
            <instance part="U603" gate="G$1" x="43.18" y="-259.08" />
            <instance part="U604" gate="G$1" x="119.38" y="-259.08" />
          </instances>
          <busses />
          <nets>
            <net name="5V_CV" class="0">
              <segment>
                <pinref part="C601" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C604" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="J601" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-81.28" x2="30.48" y2="-81.28" width="0.1524" layer="91" />
                <label x="2.54" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U601" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-203.2" x2="182.88" y2="-203.2" width="0.1524" layer="91" />
                <label x="154.94" y="-203.2" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U602" gate="G$1" pin="P5" />
                <wire x1="231.14" y1="-218.44" x2="259.08" y2="-218.44" width="0.1524" layer="91" />
                <label x="231.14" y="-218.44" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="C601" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C602" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C604" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C605" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-55.88" x2="30.48" y2="-55.88" width="0.1524" layer="91" />
                <label x="2.54" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C606" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-55.88" x2="106.68" y2="-55.88" width="0.1524" layer="91" />
                <label x="78.74" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C607" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-55.88" x2="182.88" y2="-55.88" width="0.1524" layer="91" />
                <label x="154.94" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="J601" gate="G$1" pin="P3" />
                <wire x1="2.54" y1="-91.44" x2="30.48" y2="-91.44" width="0.1524" layer="91" />
                <label x="2.54" y="-91.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R602" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-142.24" x2="106.68" y2="-142.24" width="0.1524" layer="91" />
                <label x="78.74" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R606" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-172.72" x2="106.68" y2="-172.72" width="0.1524" layer="91" />
                <label x="78.74" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R607" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-172.72" x2="182.88" y2="-172.72" width="0.1524" layer="91" />
                <label x="154.94" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R610" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-203.2" x2="106.68" y2="-203.2" width="0.1524" layer="91" />
                <label x="78.74" y="-203.2" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U601" gate="G$1" pin="P4" />
                <wire x1="154.94" y1="-213.36" x2="182.88" y2="-213.36" width="0.1524" layer="91" />
                <label x="154.94" y="-213.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U602" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-203.2" x2="259.08" y2="-203.2" width="0.1524" layer="91" />
                <label x="231.14" y="-203.2" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U603" gate="G$1" pin="P4" />
                <wire x1="2.54" y1="-274.32" x2="30.48" y2="-274.32" width="0.1524" layer="91" />
                <label x="2.54" y="-274.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U604" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-264.16" x2="106.68" y2="-264.16" width="0.1524" layer="91" />
                <label x="78.74" y="-264.16" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CV_REF" class="0">
              <segment>
                <pinref part="C602" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R603" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-137.16" x2="182.88" y2="-137.16" width="0.1524" layer="91" />
                <label x="154.94" y="-137.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U601" gate="G$1" pin="P6" />
                <wire x1="154.94" y1="-223.52" x2="182.88" y2="-223.52" width="0.1524" layer="91" />
                <label x="154.94" y="-223.52" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CV_OUT" class="0">
              <segment>
                <pinref part="C603" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="D601" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-55.88" x2="259.08" y2="-55.88" width="0.1524" layer="91" />
                <label x="231.14" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U602" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-198.12" x2="259.08" y2="-198.12" width="0.1524" layer="91" />
                <label x="231.14" y="-198.12" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CV_INV" class="0">
              <segment>
                <pinref part="C603" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R603" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-142.24" x2="182.88" y2="-142.24" width="0.1524" layer="91" />
                <label x="154.94" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U602" gate="G$1" pin="P4" />
                <wire x1="231.14" y1="-213.36" x2="259.08" y2="-213.36" width="0.1524" layer="91" />
                <label x="231.14" y="-213.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="5V_OVP" class="0">
              <segment>
                <pinref part="C605" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-50.8" x2="30.48" y2="-50.8" width="0.1524" layer="91" />
                <label x="2.54" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C607" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-50.8" x2="182.88" y2="-50.8" width="0.1524" layer="91" />
                <label x="154.94" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="J601" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-86.36" x2="30.48" y2="-86.36" width="0.1524" layer="91" />
                <label x="2.54" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U603" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-264.16" x2="30.48" y2="-264.16" width="0.1524" layer="91" />
                <label x="2.54" y="-264.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U604" gate="G$1" pin="P5" />
                <wire x1="78.74" y1="-279.4" x2="106.68" y2="-279.4" width="0.1524" layer="91" />
                <label x="78.74" y="-279.4" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="OVP_REF" class="0">
              <segment>
                <pinref part="C606" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-50.8" x2="106.68" y2="-50.8" width="0.1524" layer="91" />
                <label x="78.74" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U603" gate="G$1" pin="P6" />
                <wire x1="2.54" y1="-284.48" x2="30.48" y2="-284.48" width="0.1524" layer="91" />
                <label x="2.54" y="-284.48" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U604" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-269.24" x2="106.68" y2="-269.24" width="0.1524" layer="91" />
                <label x="78.74" y="-269.24" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CV_FB_INJ" class="0">
              <segment>
                <pinref part="D601" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-50.8" x2="259.08" y2="-50.8" width="0.1524" layer="91" />
                <label x="231.14" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R604" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-137.16" x2="259.08" y2="-137.16" width="0.1524" layer="91" />
                <label x="231.14" y="-137.16" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_FB" class="0">
              <segment>
                <pinref part="J601" gate="G$1" pin="P4" />
                <wire x1="2.54" y1="-96.52" x2="30.48" y2="-96.52" width="0.1524" layer="91" />
                <label x="2.54" y="-96.52" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R604" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-142.24" x2="259.08" y2="-142.24" width="0.1524" layer="91" />
                <label x="231.14" y="-142.24" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_DIODE_K" class="0">
              <segment>
                <pinref part="J601" gate="G$1" pin="P5" />
                <wire x1="2.54" y1="-101.6" x2="30.48" y2="-101.6" width="0.1524" layer="91" />
                <label x="2.54" y="-101.6" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q601" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-86.36" x2="106.68" y2="-86.36" width="0.1524" layer="91" />
                <label x="78.74" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R608" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-167.64" x2="259.08" y2="-167.64" width="0.1524" layer="91" />
                <label x="231.14" y="-167.64" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_SAFE_IN" class="0">
              <segment>
                <pinref part="J601" gate="G$1" pin="P6" />
                <wire x1="2.54" y1="-106.68" x2="30.48" y2="-106.68" width="0.1524" layer="91" />
                <label x="2.54" y="-106.68" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q603" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-81.28" x2="259.08" y2="-81.28" width="0.1524" layer="91" />
                <label x="231.14" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R610" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-198.12" x2="106.68" y2="-198.12" width="0.1524" layer="91" />
                <label x="78.74" y="-198.12" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_4S" class="0">
              <segment>
                <pinref part="J601" gate="G$1" pin="P7" />
                <wire x1="2.54" y1="-111.76" x2="30.48" y2="-111.76" width="0.1524" layer="91" />
                <label x="2.54" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q601" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-91.44" x2="106.68" y2="-91.44" width="0.1524" layer="91" />
                <label x="78.74" y="-91.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R601" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-137.16" x2="30.48" y2="-137.16" width="0.1524" layer="91" />
                <label x="2.54" y="-137.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R605" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-167.64" x2="30.48" y2="-167.64" width="0.1524" layer="91" />
                <label x="2.54" y="-167.64" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CUT_GATE" class="0">
              <segment>
                <pinref part="Q601" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-81.28" x2="106.68" y2="-81.28" width="0.1524" layer="91" />
                <label x="78.74" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R608" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-172.72" x2="259.08" y2="-172.72" width="0.1524" layer="91" />
                <label x="231.14" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R609" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-198.12" x2="30.48" y2="-198.12" width="0.1524" layer="91" />
                <label x="2.54" y="-198.12" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="OVP_OK" class="0">
              <segment>
                <pinref part="Q602" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-81.28" x2="182.88" y2="-81.28" width="0.1524" layer="91" />
                <label x="154.94" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R607" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-167.64" x2="182.88" y2="-167.64" width="0.1524" layer="91" />
                <label x="154.94" y="-167.64" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U604" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-259.08" x2="106.68" y2="-259.08" width="0.1524" layer="91" />
                <label x="78.74" y="-259.08" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CUT_SINK_LO" class="0">
              <segment>
                <pinref part="Q602" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-86.36" x2="182.88" y2="-86.36" width="0.1524" layer="91" />
                <label x="154.94" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q603" gate="G$1" pin="P3" />
                <wire x1="231.14" y1="-91.44" x2="259.08" y2="-91.44" width="0.1524" layer="91" />
                <label x="231.14" y="-91.44" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CUT_SINK" class="0">
              <segment>
                <pinref part="Q602" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-91.44" x2="182.88" y2="-91.44" width="0.1524" layer="91" />
                <label x="154.94" y="-91.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R609" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-203.2" x2="30.48" y2="-203.2" width="0.1524" layer="91" />
                <label x="2.54" y="-203.2" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CUT_SAFE_RETURN" class="0">
              <segment>
                <pinref part="Q603" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-86.36" x2="259.08" y2="-86.36" width="0.1524" layer="91" />
                <label x="231.14" y="-86.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CV_SENSE" class="0">
              <segment>
                <pinref part="R601" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-142.24" x2="30.48" y2="-142.24" width="0.1524" layer="91" />
                <label x="2.54" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R602" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-137.16" x2="106.68" y2="-137.16" width="0.1524" layer="91" />
                <label x="78.74" y="-137.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U602" gate="G$1" pin="P3" />
                <wire x1="231.14" y1="-208.28" x2="259.08" y2="-208.28" width="0.1524" layer="91" />
                <label x="231.14" y="-208.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="OVP_SENSE" class="0">
              <segment>
                <pinref part="R605" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-172.72" x2="30.48" y2="-172.72" width="0.1524" layer="91" />
                <label x="2.54" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R606" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-167.64" x2="106.68" y2="-167.64" width="0.1524" layer="91" />
                <label x="78.74" y="-167.64" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U604" gate="G$1" pin="P4" />
                <wire x1="78.74" y1="-274.32" x2="106.68" y2="-274.32" width="0.1524" layer="91" />
                <label x="78.74" y="-274.32" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_97" class="0">
              <segment>
                <pinref part="U601" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-198.12" x2="182.88" y2="-198.12" width="0.1524" layer="91" />
                <label x="154.94" y="-198.12" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_100" class="0">
              <segment>
                <pinref part="U601" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-208.28" x2="182.88" y2="-208.28" width="0.1524" layer="91" />
                <label x="154.94" y="-208.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_101" class="0">
              <segment>
                <pinref part="U601" gate="G$1" pin="P5" />
                <wire x1="154.94" y1="-218.44" x2="182.88" y2="-218.44" width="0.1524" layer="91" />
                <label x="154.94" y="-218.44" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_99" class="0">
              <segment>
                <pinref part="U601" gate="G$1" pin="P7" />
                <wire x1="154.94" y1="-228.6" x2="182.88" y2="-228.6" width="0.1524" layer="91" />
                <label x="154.94" y="-228.6" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_98" class="0">
              <segment>
                <pinref part="U601" gate="G$1" pin="P8" />
                <wire x1="154.94" y1="-233.68" x2="182.88" y2="-233.68" width="0.1524" layer="91" />
                <label x="154.94" y="-233.68" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_102" class="0">
              <segment>
                <pinref part="U603" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-259.08" x2="30.48" y2="-259.08" width="0.1524" layer="91" />
                <label x="2.54" y="-259.08" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_105" class="0">
              <segment>
                <pinref part="U603" gate="G$1" pin="P3" />
                <wire x1="2.54" y1="-269.24" x2="30.48" y2="-269.24" width="0.1524" layer="91" />
                <label x="2.54" y="-269.24" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_106" class="0">
              <segment>
                <pinref part="U603" gate="G$1" pin="P5" />
                <wire x1="2.54" y1="-279.4" x2="30.48" y2="-279.4" width="0.1524" layer="91" />
                <label x="2.54" y="-279.4" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_104" class="0">
              <segment>
                <pinref part="U603" gate="G$1" pin="P7" />
                <wire x1="2.54" y1="-289.56" x2="30.48" y2="-289.56" width="0.1524" layer="91" />
                <label x="2.54" y="-289.56" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_103" class="0">
              <segment>
                <pinref part="U603" gate="G$1" pin="P8" />
                <wire x1="2.54" y1="-294.64" x2="30.48" y2="-294.64" width="0.1524" layer="91" />
                <label x="2.54" y="-294.64" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | Charger Auxiliary Rails</text>
          </plain>
          <instances>
            <instance part="C701" gate="G$1" x="43.18" y="-20.32" />
            <instance part="C702" gate="G$1" x="119.38" y="-20.32" />
            <instance part="C703" gate="G$1" x="195.58" y="-20.32" />
            <instance part="C704" gate="G$1" x="271.78" y="-20.32" />
            <instance part="C705" gate="G$1" x="43.18" y="-50.8" />
            <instance part="Q703" gate="G$1" x="119.38" y="-50.8" />
            <instance part="R705" gate="G$1" x="195.58" y="-50.8" />
            <instance part="R706" gate="G$1" x="271.78" y="-50.8" />
            <instance part="U701" gate="G$1" x="43.18" y="-86.36" />
            <instance part="U702" gate="G$1" x="119.38" y="-86.36" />
            <instance part="U703" gate="G$1" x="195.58" y="-86.36" />
          </instances>
          <busses />
          <nets>
            <net name="VIN_MAIN" class="0">
              <segment>
                <pinref part="C701" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C703" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U701" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-86.36" x2="30.48" y2="-86.36" width="0.1524" layer="91" />
                <label x="2.54" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U702" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-86.36" x2="106.68" y2="-86.36" width="0.1524" layer="91" />
                <label x="78.74" y="-86.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="C701" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C702" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C703" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C704" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C705" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-55.88" x2="30.48" y2="-55.88" width="0.1524" layer="91" />
                <label x="2.54" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="Q703" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-55.88" x2="106.68" y2="-55.88" width="0.1524" layer="91" />
                <label x="78.74" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R705" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-55.88" x2="182.88" y2="-55.88" width="0.1524" layer="91" />
                <label x="154.94" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R706" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-55.88" x2="259.08" y2="-55.88" width="0.1524" layer="91" />
                <label x="231.14" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U701" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-91.44" x2="30.48" y2="-91.44" width="0.1524" layer="91" />
                <label x="2.54" y="-91.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U702" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-91.44" x2="106.68" y2="-91.44" width="0.1524" layer="91" />
                <label x="78.74" y="-91.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U703" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-96.52" x2="182.88" y2="-96.52" width="0.1524" layer="91" />
                <label x="154.94" y="-96.52" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="5V_CV" class="0">
              <segment>
                <pinref part="C702" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U701" gate="G$1" pin="P5" />
                <wire x1="2.54" y1="-106.68" x2="30.48" y2="-106.68" width="0.1524" layer="91" />
                <label x="2.54" y="-106.68" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="5V_OVP" class="0">
              <segment>
                <pinref part="C704" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U702" gate="G$1" pin="P5" />
                <wire x1="78.74" y1="-106.68" x2="106.68" y2="-106.68" width="0.1524" layer="91" />
                <label x="78.74" y="-106.68" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="3V3_CHG" class="0">
              <segment>
                <pinref part="C705" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-50.8" x2="30.48" y2="-50.8" width="0.1524" layer="91" />
                <label x="2.54" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U703" gate="G$1" pin="P5" />
                <wire x1="154.94" y1="-106.68" x2="182.88" y2="-106.68" width="0.1524" layer="91" />
                <label x="154.94" y="-106.68" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CUT_OK_BUFFERED" class="0">
              <segment>
                <pinref part="Q703" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-50.8" x2="106.68" y2="-50.8" width="0.1524" layer="91" />
                <label x="78.74" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R706" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-50.8" x2="259.08" y2="-50.8" width="0.1524" layer="91" />
                <label x="231.14" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U703" gate="G$1" pin="P4" />
                <wire x1="154.94" y1="-101.6" x2="182.88" y2="-101.6" width="0.1524" layer="91" />
                <label x="154.94" y="-101.6" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CUT_SAFE_RETURN" class="0">
              <segment>
                <pinref part="Q703" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-60.96" x2="106.68" y2="-60.96" width="0.1524" layer="91" />
                <label x="78.74" y="-60.96" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CHG_OVP_OD" class="0">
              <segment>
                <pinref part="R705" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-50.8" x2="182.88" y2="-50.8" width="0.1524" layer="91" />
                <label x="154.94" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U703" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-91.44" x2="182.88" y2="-91.44" width="0.1524" layer="91" />
                <label x="154.94" y="-91.44" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_107" class="0">
              <segment>
                <pinref part="U701" gate="G$1" pin="P3" />
                <wire x1="2.54" y1="-96.52" x2="30.48" y2="-96.52" width="0.1524" layer="91" />
                <label x="2.54" y="-96.52" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_108" class="0">
              <segment>
                <pinref part="U701" gate="G$1" pin="P4" />
                <wire x1="2.54" y1="-101.6" x2="30.48" y2="-101.6" width="0.1524" layer="91" />
                <label x="2.54" y="-101.6" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_109" class="0">
              <segment>
                <pinref part="U702" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-96.52" x2="106.68" y2="-96.52" width="0.1524" layer="91" />
                <label x="78.74" y="-96.52" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_110" class="0">
              <segment>
                <pinref part="U702" gate="G$1" pin="P4" />
                <wire x1="78.74" y1="-101.6" x2="106.68" y2="-101.6" width="0.1524" layer="91" />
                <label x="78.74" y="-101.6" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_111" class="0">
              <segment>
                <pinref part="U703" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-86.36" x2="182.88" y2="-86.36" width="0.1524" layer="91" />
                <label x="154.94" y="-86.36" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | BQ76905 4S cell monitor</text>
          </plain>
          <instances>
            <instance part="C801" gate="G$1" x="43.18" y="-20.32" />
            <instance part="C802" gate="G$1" x="119.38" y="-20.32" />
            <instance part="C803" gate="G$1" x="195.58" y="-20.32" />
            <instance part="C804" gate="G$1" x="271.78" y="-20.32" />
            <instance part="C805" gate="G$1" x="43.18" y="-50.8" />
            <instance part="C806" gate="G$1" x="119.38" y="-50.8" />
            <instance part="C807" gate="G$1" x="195.58" y="-50.8" />
            <instance part="C808" gate="G$1" x="271.78" y="-50.8" />
            <instance part="D801" gate="G$1" x="43.18" y="-81.28" />
            <instance part="D802" gate="G$1" x="119.38" y="-81.28" />
            <instance part="R801" gate="G$1" x="195.58" y="-81.28" />
            <instance part="R802" gate="G$1" x="271.78" y="-81.28" />
            <instance part="R803" gate="G$1" x="43.18" y="-111.76" />
            <instance part="R804" gate="G$1" x="119.38" y="-111.76" />
            <instance part="R805" gate="G$1" x="195.58" y="-111.76" />
            <instance part="R806" gate="G$1" x="271.78" y="-111.76" />
            <instance part="R807" gate="G$1" x="43.18" y="-142.24" />
            <instance part="R808" gate="G$1" x="119.38" y="-142.24" />
            <instance part="R809" gate="G$1" x="195.58" y="-142.24" />
            <instance part="R810" gate="G$1" x="271.78" y="-142.24" />
            <instance part="U801" gate="G$1" x="43.18" y="-172.72" />
          </instances>
          <busses />
          <nets>
            <net name="VC0_SENSE" class="0">
              <segment>
                <pinref part="C801" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C802" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R801" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-86.36" x2="182.88" y2="-86.36" width="0.1524" layer="91" />
                <label x="154.94" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P5" />
                <wire x1="2.54" y1="-193.04" x2="30.48" y2="-193.04" width="0.1524" layer="91" />
                <label x="2.54" y="-193.04" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="C801" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C806" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-55.88" x2="106.68" y2="-55.88" width="0.1524" layer="91" />
                <label x="78.74" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C807" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-55.88" x2="182.88" y2="-55.88" width="0.1524" layer="91" />
                <label x="154.94" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C808" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-55.88" x2="259.08" y2="-55.88" width="0.1524" layer="91" />
                <label x="231.14" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R801" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-81.28" x2="182.88" y2="-81.28" width="0.1524" layer="91" />
                <label x="154.94" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P6" />
                <wire x1="2.54" y1="-198.12" x2="30.48" y2="-198.12" width="0.1524" layer="91" />
                <label x="2.54" y="-198.12" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P7" />
                <wire x1="2.54" y1="-203.2" x2="30.48" y2="-203.2" width="0.1524" layer="91" />
                <label x="2.54" y="-203.2" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P8" />
                <wire x1="2.54" y1="-208.28" x2="30.48" y2="-208.28" width="0.1524" layer="91" />
                <label x="2.54" y="-208.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P11" />
                <wire x1="2.54" y1="-223.52" x2="30.48" y2="-223.52" width="0.1524" layer="91" />
                <label x="2.54" y="-223.52" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="VC1_SENSE" class="0">
              <segment>
                <pinref part="C802" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C803" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R802" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-86.36" x2="259.08" y2="-86.36" width="0.1524" layer="91" />
                <label x="231.14" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P4" />
                <wire x1="2.54" y1="-187.96" x2="30.48" y2="-187.96" width="0.1524" layer="91" />
                <label x="2.54" y="-187.96" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL2_SENSE" class="0">
              <segment>
                <pinref part="C803" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C804" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R803" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-116.84" x2="30.48" y2="-116.84" width="0.1524" layer="91" />
                <label x="2.54" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-172.72" x2="30.48" y2="-172.72" width="0.1524" layer="91" />
                <label x="2.54" y="-172.72" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-177.8" x2="30.48" y2="-177.8" width="0.1524" layer="91" />
                <label x="2.54" y="-177.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P3" />
                <wire x1="2.54" y1="-182.88" x2="30.48" y2="-182.88" width="0.1524" layer="91" />
                <label x="2.54" y="-182.88" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL3_SENSE" class="0">
              <segment>
                <pinref part="C804" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="C805" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-50.8" x2="30.48" y2="-50.8" width="0.1524" layer="91" />
                <label x="2.54" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R804" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-116.84" x2="106.68" y2="-116.84" width="0.1524" layer="91" />
                <label x="78.74" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P19" />
                <wire x1="2.54" y1="-264.16" x2="30.48" y2="-264.16" width="0.1524" layer="91" />
                <label x="2.54" y="-264.16" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P20" />
                <wire x1="2.54" y1="-269.24" x2="30.48" y2="-269.24" width="0.1524" layer="91" />
                <label x="2.54" y="-269.24" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_SENSE" class="0">
              <segment>
                <pinref part="C805" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-55.88" x2="30.48" y2="-55.88" width="0.1524" layer="91" />
                <label x="2.54" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R805" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-116.84" x2="182.88" y2="-116.84" width="0.1524" layer="91" />
                <label x="154.94" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P18" />
                <wire x1="2.54" y1="-259.08" x2="30.48" y2="-259.08" width="0.1524" layer="91" />
                <label x="2.54" y="-259.08" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="BAT_FILTERED" class="0">
              <segment>
                <pinref part="C806" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-50.8" x2="106.68" y2="-50.8" width="0.1524" layer="91" />
                <label x="78.74" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R806" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-116.84" x2="259.08" y2="-116.84" width="0.1524" layer="91" />
                <label x="231.14" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P17" />
                <wire x1="2.54" y1="-254.0" x2="30.48" y2="-254.0" width="0.1524" layer="91" />
                <label x="2.54" y="-254.0" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="REGSRC_FILTERED" class="0">
              <segment>
                <pinref part="C807" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-50.8" x2="182.88" y2="-50.8" width="0.1524" layer="91" />
                <label x="154.94" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R807" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-147.32" x2="30.48" y2="-147.32" width="0.1524" layer="91" />
                <label x="2.54" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P16" />
                <wire x1="2.54" y1="-248.92" x2="30.48" y2="-248.92" width="0.1524" layer="91" />
                <label x="2.54" y="-248.92" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_3V3" class="0">
              <segment>
                <pinref part="C808" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-50.8" x2="259.08" y2="-50.8" width="0.1524" layer="91" />
                <label x="231.14" y="-50.8" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R808" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-142.24" x2="106.68" y2="-142.24" width="0.1524" layer="91" />
                <label x="78.74" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R809" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-142.24" x2="182.88" y2="-142.24" width="0.1524" layer="91" />
                <label x="154.94" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R810" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-142.24" x2="259.08" y2="-142.24" width="0.1524" layer="91" />
                <label x="231.14" y="-142.24" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P15" />
                <wire x1="2.54" y1="-243.84" x2="30.48" y2="-243.84" width="0.1524" layer="91" />
                <label x="2.54" y="-243.84" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_69" class="0">
              <segment>
                <pinref part="D801" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-81.28" x2="30.48" y2="-81.28" width="0.1524" layer="91" />
                <label x="2.54" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R806" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-111.76" x2="259.08" y2="-111.76" width="0.1524" layer="91" />
                <label x="231.14" y="-111.76" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_4S" class="0">
              <segment>
                <pinref part="D801" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-86.36" x2="30.48" y2="-86.36" width="0.1524" layer="91" />
                <label x="2.54" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="D802" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-86.36" x2="106.68" y2="-86.36" width="0.1524" layer="91" />
                <label x="78.74" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R805" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-111.76" x2="182.88" y2="-111.76" width="0.1524" layer="91" />
                <label x="154.94" y="-111.76" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NET_70" class="0">
              <segment>
                <pinref part="D802" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-81.28" x2="106.68" y2="-81.28" width="0.1524" layer="91" />
                <label x="78.74" y="-81.28" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R807" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-142.24" x2="30.48" y2="-142.24" width="0.1524" layer="91" />
                <label x="2.54" y="-142.24" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_1" class="0">
              <segment>
                <pinref part="R802" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-81.28" x2="259.08" y2="-81.28" width="0.1524" layer="91" />
                <label x="231.14" y="-81.28" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_2" class="0">
              <segment>
                <pinref part="R803" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-111.76" x2="30.48" y2="-111.76" width="0.1524" layer="91" />
                <label x="2.54" y="-111.76" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_3" class="0">
              <segment>
                <pinref part="R804" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-111.76" x2="106.68" y2="-111.76" width="0.1524" layer="91" />
                <label x="78.74" y="-111.76" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_I2C_SCL" class="0">
              <segment>
                <pinref part="R808" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-147.32" x2="106.68" y2="-147.32" width="0.1524" layer="91" />
                <label x="78.74" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P12" />
                <wire x1="2.54" y1="-228.6" x2="30.48" y2="-228.6" width="0.1524" layer="91" />
                <label x="2.54" y="-228.6" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_I2C_SDA" class="0">
              <segment>
                <pinref part="R809" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-147.32" x2="182.88" y2="-147.32" width="0.1524" layer="91" />
                <label x="154.94" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P13" />
                <wire x1="2.54" y1="-233.68" x2="30.48" y2="-233.68" width="0.1524" layer="91" />
                <label x="2.54" y="-233.68" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_MON_ALERT_L" class="0">
              <segment>
                <pinref part="R810" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-147.32" x2="259.08" y2="-147.32" width="0.1524" layer="91" />
                <label x="231.14" y="-147.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U801" gate="G$1" pin="P14" />
                <wire x1="2.54" y1="-238.76" x2="30.48" y2="-238.76" width="0.1524" layer="91" />
                <label x="2.54" y="-238.76" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_113" class="0">
              <segment>
                <pinref part="U801" gate="G$1" pin="P9" />
                <wire x1="2.54" y1="-213.36" x2="30.48" y2="-213.36" width="0.1524" layer="91" />
                <label x="2.54" y="-213.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_112" class="0">
              <segment>
                <pinref part="U801" gate="G$1" pin="P10" />
                <wire x1="2.54" y1="-218.44" x2="30.48" y2="-218.44" width="0.1524" layer="91" />
                <label x="2.54" y="-218.44" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
        <sheet>
          <plain>
            <text x="5.08" y="10.16" size="2.54" layer="97">Supercap UPS | System Interlock</text>
          </plain>
          <instances>
            <instance part="C910" gate="G$1" x="43.18" y="-20.32" />
            <instance part="D910" gate="G$1" x="119.38" y="-20.32" />
            <instance part="J910" gate="G$1" x="195.58" y="-20.32" />
            <instance part="R910" gate="G$1" x="271.78" y="-20.32" />
            <instance part="R911" gate="G$1" x="43.18" y="-55.88" />
            <instance part="R912" gate="G$1" x="119.38" y="-55.88" />
            <instance part="R913" gate="G$1" x="195.58" y="-55.88" />
            <instance part="R914" gate="G$1" x="271.78" y="-55.88" />
            <instance part="R915" gate="G$1" x="43.18" y="-86.36" />
            <instance part="U910" gate="G$1" x="119.38" y="-86.36" />
            <instance part="U911" gate="G$1" x="195.58" y="-86.36" />
            <instance part="U912" gate="G$1" x="271.78" y="-86.36" />
            <instance part="U913" gate="G$1" x="43.18" y="-147.32" />
            <instance part="U914" gate="G$1" x="119.38" y="-147.32" />
            <instance part="U915" gate="G$1" x="195.58" y="-147.32" />
          </instances>
          <busses />
          <nets>
            <net name="BOOST_EN_DELAY" class="0">
              <segment>
                <pinref part="C910" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-20.32" x2="30.48" y2="-20.32" width="0.1524" layer="91" />
                <label x="2.54" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="D910" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-25.4" x2="106.68" y2="-25.4" width="0.1524" layer="91" />
                <label x="78.74" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R910" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-25.4" x2="259.08" y2="-25.4" width="0.1524" layer="91" />
                <label x="231.14" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R911" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-55.88" x2="30.48" y2="-55.88" width="0.1524" layer="91" />
                <label x="2.54" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U915" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-152.4" x2="182.88" y2="-152.4" width="0.1524" layer="91" />
                <label x="154.94" y="-152.4" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="GND" class="0">
              <segment>
                <pinref part="C910" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-25.4" x2="30.48" y2="-25.4" width="0.1524" layer="91" />
                <label x="2.54" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="J910" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-30.48" x2="182.88" y2="-30.48" width="0.1524" layer="91" />
                <label x="154.94" y="-30.48" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R911" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-60.96" x2="30.48" y2="-60.96" width="0.1524" layer="91" />
                <label x="2.54" y="-60.96" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R912" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-60.96" x2="106.68" y2="-60.96" width="0.1524" layer="91" />
                <label x="78.74" y="-60.96" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R913" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-60.96" x2="182.88" y2="-60.96" width="0.1524" layer="91" />
                <label x="154.94" y="-60.96" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R914" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-60.96" x2="259.08" y2="-60.96" width="0.1524" layer="91" />
                <label x="231.14" y="-60.96" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R915" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-91.44" x2="30.48" y2="-91.44" width="0.1524" layer="91" />
                <label x="2.54" y="-91.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U910" gate="G$1" pin="P4" />
                <wire x1="78.74" y1="-101.6" x2="106.68" y2="-101.6" width="0.1524" layer="91" />
                <label x="78.74" y="-101.6" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U911" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-96.52" x2="182.88" y2="-96.52" width="0.1524" layer="91" />
                <label x="154.94" y="-96.52" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U912" gate="G$1" pin="P3" />
                <wire x1="231.14" y1="-96.52" x2="259.08" y2="-96.52" width="0.1524" layer="91" />
                <label x="231.14" y="-96.52" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U913" gate="G$1" pin="P3" />
                <wire x1="2.54" y1="-157.48" x2="30.48" y2="-157.48" width="0.1524" layer="91" />
                <label x="2.54" y="-157.48" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U914" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-157.48" x2="106.68" y2="-157.48" width="0.1524" layer="91" />
                <label x="78.74" y="-157.48" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U915" gate="G$1" pin="P3" />
                <wire x1="154.94" y1="-157.48" x2="182.88" y2="-157.48" width="0.1524" layer="91" />
                <label x="154.94" y="-157.48" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="DISCHARGE_ARM" class="0">
              <segment>
                <pinref part="D910" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-20.32" x2="106.68" y2="-20.32" width="0.1524" layer="91" />
                <label x="78.74" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R910" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-20.32" x2="259.08" y2="-20.32" width="0.1524" layer="91" />
                <label x="231.14" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R913" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-55.88" x2="182.88" y2="-55.88" width="0.1524" layer="91" />
                <label x="154.94" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U910" gate="G$1" pin="P5" />
                <wire x1="78.74" y1="-106.68" x2="106.68" y2="-106.68" width="0.1524" layer="91" />
                <label x="78.74" y="-106.68" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_CONFIG_VALID" class="0">
              <segment>
                <pinref part="J910" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-20.32" x2="182.88" y2="-20.32" width="0.1524" layer="91" />
                <label x="154.94" y="-20.32" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R914" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-55.88" x2="259.08" y2="-55.88" width="0.1524" layer="91" />
                <label x="231.14" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U912" gate="G$1" pin="P1" />
                <wire x1="231.14" y1="-86.36" x2="259.08" y2="-86.36" width="0.1524" layer="91" />
                <label x="231.14" y="-86.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="MANUAL_ARM_REQ" class="0">
              <segment>
                <pinref part="J910" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-25.4" x2="182.88" y2="-25.4" width="0.1524" layer="91" />
                <label x="154.94" y="-25.4" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="R915" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-86.36" x2="30.48" y2="-86.36" width="0.1524" layer="91" />
                <label x="2.54" y="-86.36" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U910" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-86.36" x2="106.68" y2="-86.36" width="0.1524" layer="91" />
                <label x="78.74" y="-86.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="BOOST_EN" class="0">
              <segment>
                <pinref part="R912" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-55.88" x2="106.68" y2="-55.88" width="0.1524" layer="91" />
                <label x="78.74" y="-55.88" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U915" gate="G$1" pin="P4" />
                <wire x1="154.94" y1="-162.56" x2="182.88" y2="-162.56" width="0.1524" layer="91" />
                <label x="154.94" y="-162.56" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_3V3" class="0">
              <segment>
                <pinref part="U910" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-91.44" x2="106.68" y2="-91.44" width="0.1524" layer="91" />
                <label x="78.74" y="-91.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U910" gate="G$1" pin="P7" />
                <wire x1="78.74" y1="-116.84" x2="106.68" y2="-116.84" width="0.1524" layer="91" />
                <label x="78.74" y="-116.84" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U910" gate="G$1" pin="P8" />
                <wire x1="78.74" y1="-121.92" x2="106.68" y2="-121.92" width="0.1524" layer="91" />
                <label x="78.74" y="-121.92" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U911" gate="G$1" pin="P5" />
                <wire x1="154.94" y1="-106.68" x2="182.88" y2="-106.68" width="0.1524" layer="91" />
                <label x="154.94" y="-106.68" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U912" gate="G$1" pin="P5" />
                <wire x1="231.14" y1="-106.68" x2="259.08" y2="-106.68" width="0.1524" layer="91" />
                <label x="231.14" y="-106.68" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U913" gate="G$1" pin="P5" />
                <wire x1="2.54" y1="-167.64" x2="30.48" y2="-167.64" width="0.1524" layer="91" />
                <label x="2.54" y="-167.64" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U914" gate="G$1" pin="P4" />
                <wire x1="78.74" y1="-162.56" x2="106.68" y2="-162.56" width="0.1524" layer="91" />
                <label x="78.74" y="-162.56" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U915" gate="G$1" pin="P5" />
                <wire x1="154.94" y1="-167.64" x2="182.88" y2="-167.64" width="0.1524" layer="91" />
                <label x="154.94" y="-167.64" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_114" class="0">
              <segment>
                <pinref part="U910" gate="G$1" pin="P3" />
                <wire x1="78.74" y1="-96.52" x2="106.68" y2="-96.52" width="0.1524" layer="91" />
                <label x="78.74" y="-96.52" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="ARM_PERMIT" class="0">
              <segment>
                <pinref part="U910" gate="G$1" pin="P6" />
                <wire x1="78.74" y1="-111.76" x2="106.68" y2="-111.76" width="0.1524" layer="91" />
                <label x="78.74" y="-111.76" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U913" gate="G$1" pin="P4" />
                <wire x1="2.54" y1="-162.56" x2="30.48" y2="-162.56" width="0.1524" layer="91" />
                <label x="2.54" y="-162.56" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="PACK_UV_OK" class="0">
              <segment>
                <pinref part="U911" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-86.36" x2="182.88" y2="-86.36" width="0.1524" layer="91" />
                <label x="154.94" y="-86.36" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_MON_PG" class="0">
              <segment>
                <pinref part="U911" gate="G$1" pin="P2" />
                <wire x1="154.94" y1="-91.44" x2="182.88" y2="-91.44" width="0.1524" layer="91" />
                <label x="154.94" y="-91.44" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U914" gate="G$1" pin="P1" />
                <wire x1="78.74" y1="-147.32" x2="106.68" y2="-147.32" width="0.1524" layer="91" />
                <label x="78.74" y="-147.32" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="SAFE_A" class="0">
              <segment>
                <pinref part="U911" gate="G$1" pin="P4" />
                <wire x1="154.94" y1="-101.6" x2="182.88" y2="-101.6" width="0.1524" layer="91" />
                <label x="154.94" y="-101.6" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U913" gate="G$1" pin="P1" />
                <wire x1="2.54" y1="-147.32" x2="30.48" y2="-147.32" width="0.1524" layer="91" />
                <label x="2.54" y="-147.32" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="CELL_MON_ALERT_L" class="0">
              <segment>
                <pinref part="U912" gate="G$1" pin="P2" />
                <wire x1="231.14" y1="-91.44" x2="259.08" y2="-91.44" width="0.1524" layer="91" />
                <label x="231.14" y="-91.44" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="SAFE_B" class="0">
              <segment>
                <pinref part="U912" gate="G$1" pin="P4" />
                <wire x1="231.14" y1="-101.6" x2="259.08" y2="-101.6" width="0.1524" layer="91" />
                <label x="231.14" y="-101.6" size="1.016" layer="95" />
              </segment>
              <segment>
                <pinref part="U913" gate="G$1" pin="P2" />
                <wire x1="2.54" y1="-152.4" x2="30.48" y2="-152.4" width="0.1524" layer="91" />
                <label x="2.54" y="-152.4" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_115" class="0">
              <segment>
                <pinref part="U914" gate="G$1" pin="P2" />
                <wire x1="78.74" y1="-152.4" x2="106.68" y2="-152.4" width="0.1524" layer="91" />
                <label x="78.74" y="-152.4" size="1.016" layer="95" />
              </segment>
            </net>
            <net name="NC_116" class="0">
              <segment>
                <pinref part="U915" gate="G$1" pin="P1" />
                <wire x1="154.94" y1="-147.32" x2="182.88" y2="-147.32" width="0.1524" layer="91" />
                <label x="154.94" y="-147.32" size="1.016" layer="95" />
              </segment>
            </net>
          </nets>
        </sheet>
      </sheets>
    </schematic>
  </drawing>
</eagle>